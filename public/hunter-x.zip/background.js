/* Hunter X v2.1 — service worker (MV3) */

const VERSION_URL = 'https://hunterx.site/api/version';
const CURRENT_VERSION = '2.2.0';

// ─── Inicialização ───────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(["savedAds", "stats", "minDaysFilter"]);
  if (!cur.savedAds) await chrome.storage.local.set({ savedAds: [] });
  if (!cur.stats) await chrome.storage.local.set({ stats: { low: 0, mid: 0, high: 0, total: 0 } });
  if (cur.minDaysFilter == null) await chrome.storage.local.set({ minDaysFilter: 0 });

  // Agenda checagem de versão + licença a cada 6 horas
  chrome.alarms.create('checkUpdate', { delayInMinutes: 5, periodInMinutes: 360 });
  chrome.alarms.create('checkLicense', { delayInMinutes: 1, periodInMinutes: 360 });

  // Checa imediatamente na instalação
  checkForUpdate();
  checkLicense();
});

// Checa update quando o alarm disparar
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkUpdate') checkForUpdate();
  if (alarm.name === 'checkLicense') checkLicense();
});

// ─── Verificador de versão ───────────────────────────────────────────────────
async function checkForUpdate() {
  try {
    const resp = await fetch(`${VERSION_URL}?v=${Date.now()}`, {
      cache: 'no-store',
      credentials: 'omit',
    });
    if (!resp.ok) return;
    const data = await resp.json();
    const latest = data.version;

    if (!latest || latest === CURRENT_VERSION) return;

    // Versão nova disponível → verifica se já notificou
    const { lastNotifiedVersion } = await chrome.storage.local.get('lastNotifiedVersion');
    if (lastNotifiedVersion === latest) return; // já notificou

    // Salva a versão notificada
    await chrome.storage.local.set({
      lastNotifiedVersion: latest,
      updateAvailable: { version: latest, url: data.update_page, changelog: data.changelog }
    });

    // Mostra notificação nativa do Chrome
    chrome.notifications.create('hx-update', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: `🎯 Hunter X ${latest} disponível!`,
      message: data.changelog || 'Clique para baixar a nova versão.',
      priority: 2,
      buttons: [{ title: '⬇️ Atualizar agora' }],
    });
  } catch (e) {
    // silencioso — sem internet não quebra
  }
}

// ─── Verificador de licença ──────────────────────────────────────────────────
async function checkLicense() {
  try {
    const { licenseKey } = await chrome.storage.local.get('licenseKey');
    if (!licenseKey) return;

    const resp = await fetch('https://hunterx.site/api/verify-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: licenseKey }),
    });
    if (!resp.ok) return;

    const data = await resp.json();
    if (!data.valid) {
      await chrome.storage.local.remove(['licenseKey', 'licenseValid']);
      await chrome.storage.local.set({ licenseExpired: data.reason || 'invalid' });
    }
  } catch (e) {
    // sem internet não revoga — aguarda próxima checagem
  }
}

// Clique na notificação → abre página de download
chrome.notifications.onClicked.addListener((id) => {
  if (id === 'hx-update') {
    chrome.tabs.create({ url: 'https://hunterx.site/download' });
    chrome.notifications.clear(id);
  }
});

// Botão "Atualizar agora" dentro da notificação
chrome.notifications.onButtonClicked.addListener((id, btnIdx) => {
  if (id === 'hx-update' && btnIdx === 0) {
    chrome.tabs.create({ url: 'https://hunterx.site/download' });
    chrome.notifications.clear(id);
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === "SAVE_AD") {
    (async () => {
      const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
      if (!savedAds.some(a => a.id === msg.data.id)) {
        savedAds.push(msg.data);
        await chrome.storage.local.set({ savedAds });
      }
      sendResponse({ ok: true, count: savedAds.length });
    })();
    return true;
  }

  if (msg.type === "STATS_UPDATE") {
    (async () => {
      await chrome.storage.local.set({ stats: msg.stats });
      if (sender.tab) {
        chrome.action.setBadgeText({
          tabId: sender.tab.id,
          text: msg.stats.low > 0 ? String(msg.stats.low) : ""
        });
        chrome.action.setBadgeBackgroundColor({ color: "#00c853" });
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.type === "GET_SAVED") {
    (async () => {
      const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
      sendResponse({ ok: true, savedAds });
    })();
    return true;
  }

  if (msg.type === "FETCH_URL") {
    (async () => {
      try {
        const resp = await fetch(msg.url, {
          method: "GET",
          redirect: "follow",
          credentials: "omit",
          headers: { "User-Agent": "Mozilla/5.0" }
        });
        const ct = resp.headers.get("content-type") || "";
        const finalUrl = resp.url || msg.url;
        const buf = await resp.arrayBuffer();
        // Converte para base64 pra mandar via message (binary-safe)
        const bytes = new Uint8Array(buf);
        let bin = "";
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
          bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
        }
        const b64 = btoa(bin);
        sendResponse({
          ok: true,
          status: resp.status,
          contentType: ct,
          finalUrl,
          size: buf.byteLength,
          dataB64: b64
        });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true;
  }

  if (msg.type === "DOWNLOAD_VIDEO") {
    (async () => {
      try {
        const downloadId = await chrome.downloads.download({
          url: msg.url,
          filename: msg.filename || `meta-ad-${Date.now()}.mp4`,
          saveAs: false,
          conflictAction: "uniquify"
        });
        sendResponse({ ok: true, downloadId });
      } catch (err) {
        console.error("[LTH] download error:", err);
        sendResponse({ ok: false, error: String(err) });
      }
    })();
    return true;
  }
});
