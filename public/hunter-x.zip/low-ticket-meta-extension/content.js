/* =========================================================================
   LOW TICKET HUNTER v1.1 — content script
   - Detecta low ticket por preço
   - Detecta tempo rodando (dias)
   - Botão "🔗 Abrir LP"
   - Botão "📥 Baixar vídeo"
   - Filtro de dias mínimos rodando
   ========================================================================= */

(() => {
  "use strict";

  const LOG = (...args) => console.log("%c[LTH]", "color:#00c853;font-weight:bold", ...args);
  const WARN = (...args) => console.warn("%c[LTH]", "color:#ff9800;font-weight:bold", ...args);
  const ERR = (...args) => console.error("%c[LTH]", "color:#f44336;font-weight:bold", ...args);

  LOG("v1.3.1 inicializando...");

  // ---------- CONFIG ----------
  const LOW_TICKET_MAX = 100.00;
  const MID_TICKET_MAX = 500.00;

  const STRICT_PRICE_REGEX = /(?:R\$\s?|RS\s?)(\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?|\d+(?:,\d{1,2})?|\d+(?:\.\d{1,2})?)|(\d+(?:[.,]\d{1,2})?)\s*reais\b/gi;

  const TRIGGER_WORDS = [
    // Originais
    "ebook", "e-book", "pdf", "checklist", "minicurso", "mini curso",
    "método", "metodo", "passo a passo", "vitalício", "vitalicio",
    "por apenas", "promoção", "promocao", "oferta", "última chance",
    "ultima chance", "garanta já", "garanta ja", "acesso imediato",
    "bônus", "bonus", "guia completo", "treinamento", "aula gratuita",

    // 10 novas (alta conversão / muito usadas em low ticket 2025-2026)
    "pix com 10% off", "no pix",                  // 1. PIX
    "vagas limitadas", "últimas vagas",           // 2. urgência por escassez
    "garantia de 7 dias", "garantia incondicional", "7 dias para testar",  // 3. garantia
    "menos de 1 real por dia", "menos de r$ 1 por dia",  // 4. ancoragem barata
    "antes que esgote", "antes que acabe", "promo relâmpago", "promo relampago",  // 5. urgência por tempo
    "viralizou", "que viralizou", "todo mundo está usando", "todo mundo esta usando",  // 6. prova social
    "descobri", "ninguém te conta", "ninguem te conta", "segredo",  // 7. curiosidade / fofoca
    "em 7 dias", "em 30 dias", "em apenas 7 dias",  // 8. promessa temporal
    "atenção", "alerta", "urgente", "leia antes",  // 9. interrupção / pattern interrupt
    "satisfação ou seu dinheiro de volta", "dinheiro de volta", "reembolso total"  // 10. inversão de risco
  ];

  // ---------- PLATAFORMAS DE VENDA ----------
  // Detecta plataforma via URL da LP ou keyword no texto
  const PLATFORMS = {
    "hotmart":   { url: /hotmart\.com|pay\.hotmart\.com/i,            kw: ["hotmart"] },
    "kiwify":    { url: /kiwify\.(com|app|com\.br)/i,                 kw: ["kiwify"] },
    "eduzz":     { url: /eduzz\.com|sun\.eduzz|eduzz\.online/i,       kw: ["eduzz"] },
    "monetizze": { url: /monetizze\.com\.br/i,                        kw: ["monetizze"] },
    "perfectpay":{ url: /perfectpay\.com\.br|pay\.perfectpay/i,       kw: ["perfect pay", "perfectpay"] },
    "cakto":     { url: /cakto\.com\.br|pay\.cakto/i,                 kw: ["cakto"] },
    "pepper":    { url: /pepper\.com\.br/i,                           kw: ["pepper"] },
    "shopee":    { url: /shopee\.com\.br/i,                           kw: ["shopee"] },
    "mercadolivre": { url: /mercadolivre\.com\.br|mlstatic/i,         kw: ["mercado livre", "mercadolivre"] },
    "amazon":    { url: /amazon\.com\.br|amazon\.com/i,               kw: ["amazon.com.br"] },
    "shopify":   { url: /myshopify\.com|\.shopify\.com/i,             kw: [] },
    "yampi":     { url: /yampi\.com\.br/i,                            kw: ["yampi"] },
    "nuvemshop": { url: /nuvemshop\.com\.br|tiendanube/i,             kw: ["nuvemshop"] },
    "ticto":     { url: /ticto\.com\.br/i,                            kw: ["ticto"] },
    "lastlink":  { url: /lastlink\.com/i,                             kw: ["lastlink"] }
  };

  function platformLabel(p) {
    return ({
      "hotmart":"🟠 Hotmart","kiwify":"🟣 Kiwify","eduzz":"🟡 Eduzz",
      "monetizze":"🔵 Monetizze","perfectpay":"🟢 PerfectPay","cakto":"🟢 Cakto",
      "pepper":"🌶 Pepper","shopee":"🟠 Shopee","mercadolivre":"🟡 Mercado Livre",
      "amazon":"⬛ Amazon","shopify":"🟢 Shopify","yampi":"🟣 Yampi",
      "nuvemshop":"🔵 Nuvemshop","ticto":"⚫ Ticto","lastlink":"🟦 Lastlink"
    })[p] || ("🏪 " + p);
  }

  function detectPlatform(lp, textLower) {
    if (lp) {
      for (const [name, def] of Object.entries(PLATFORMS)) {
        if (def.url.test(lp)) return name;
      }
    }
    for (const [name, def] of Object.entries(PLATFORMS)) {
      for (const kw of def.kw) if (textLower.includes(kw)) return name;
    }
    return null;
  }

  // ---------- GARANTIA ----------
  function detectGuarantee(text) {
    const re = /garantia\s+(?:incondicional\s+)?de\s+(\d{1,3})\s*dias?|(\d{1,3})\s*dias?\s+(?:de\s+)?garantia|(\d{1,3})\s*dias?\s+para\s+testar/i;
    const m = text.match(re);
    if (!m) return null;
    const days = parseInt(m[1] || m[2] || m[3], 10);
    return isNaN(days) ? null : days;
  }

  const NICHES = {
    "renda_extra": [
      "renda extra", "ganhar dinheiro", "dinheiro online", "trabalhar em casa",
      "home office", "freela", "afilia", "dropship", "gringa", "hotmart",
      "monetizar", "instagram pago", "tiktok pago", "marketing digital",
      "negocio online", "negócio online", "fature", "faturar"
    ],
    "saude_emagrecimento": [
      "emagrec", "perder peso", "secar", "barriga", "celulite",
      "dieta", "low carb", "jejum", "treino", "musculação", "musculacao",
      "academia", "fitness", "saúde", "saude", "detox", "shape"
    ],
    "relacionamento": [
      "reconquist", "ex namorad", "ex marid", "relacionamento",
      "autoestima", "auto estima", "sedução", "seducao", "conquistar",
      "casamento", "amor próprio", "amor proprio"
    ],
    "espiritualidade": [
      "manifestação", "manifestacao", "lei da atração", "lei da atracao",
      "tarot", "anjo", "oração", "oracao", "numerologia", "astrologia",
      "energia", "abundância", "abundancia"
    ]
  };

  const MONTHS_PT = {
    "jan": 0, "janeiro": 0, "fev": 1, "fevereiro": 1, "mar": 2, "março": 2, "marco": 2,
    "abr": 3, "abril": 3, "mai": 4, "maio": 4, "jun": 5, "junho": 5,
    "jul": 6, "julho": 6, "ago": 7, "agosto": 7, "set": 8, "setembro": 8,
    "out": 9, "outubro": 9, "nov": 10, "novembro": 10, "dez": 11, "dezembro": 11
  };
  const MONTHS_EN = {
    "jan": 0, "january": 0, "feb": 1, "february": 1, "mar": 2, "march": 2,
    "apr": 3, "april": 3, "may": 4, "jun": 5, "june": 5, "jul": 6, "july": 6,
    "aug": 7, "august": 7, "sep": 8, "sept": 8, "september": 8,
    "oct": 9, "october": 9, "nov": 10, "november": 10, "dec": 11, "december": 11
  };

  // ---------- STATE ----------
  const processedAds = new WeakSet();
  const detectedAds = new Map();   // id → ad
  const cardById = new Map();      // id → DOM element
  let scanCount = 0;
  let minDaysFilter = 0;           // filtro: ≥ X dias rodando
  let onlyLowTicket = false;       // filtro: só low ticket
  let minViralScore = 0;           // filtro: score viral mínimo (0-100)
  let autoScrollActive = false;    // auto-scroll on/off
  let autoScrollTimer = null;

  let typeFilter = {               // filtro: quais tipos de oferta mostrar
    ecommerce: true,
    digital: true,
    outro: true,
    servico: false,
    dorama: false
  };

  // Agrupamento por anunciante (pra detectar variações)
  const adsByAdvertiser = new Map();  // advertiser → Set<adId>
  const adsByCopyFp     = new Map();  // copyFingerprint → Set<adId>
  let advertiserFilter = null;        // se setado, mostra só desse anunciante

  // Carrega configurações salvas
  try {
    chrome.storage.local.get(
      ["minDaysFilter", "typeFilter", "onlyLowTicket", "minViralScore"],
      (r) => {
        minDaysFilter = parseInt(r.minDaysFilter || 0, 10) || 0;
        onlyLowTicket = !!r.onlyLowTicket;
        minViralScore = parseInt(r.minViralScore || 0, 10) || 0;
        if (r.typeFilter && typeof r.typeFilter === "object") {
          typeFilter = Object.assign(typeFilter, r.typeFilter);
        }
        syncToggleUI();
        applyFilter();
      }
    );
  } catch (e) {}

  // ---------- HELPERS ----------
  function parsePrice(str) {
    if (!str) return NaN;
    let s = String(str).trim();
    if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(s)) s = s.replace(/\./g, "").replace(",", ".");
    else if (/^\d+,\d{1,2}$/.test(s)) s = s.replace(",", ".");
    const n = parseFloat(s);
    return isNaN(n) ? NaN : n;
  }

  function extractPrices(text) {
    if (!text) return [];
    const prices = [];
    let m;
    STRICT_PRICE_REGEX.lastIndex = 0;
    while ((m = STRICT_PRICE_REGEX.exec(text)) !== null) {
      const raw = m[1] || m[2];
      const v = parsePrice(raw);
      if (!isNaN(v) && v >= 1 && v <= 99999) prices.push({ raw: m[0].trim(), value: v });
    }
    return prices;
  }

  function classifyTicket(price) {
    if (price <= LOW_TICKET_MAX) return "low";
    if (price <= MID_TICKET_MAX) return "mid";
    return "high";
  }

  function detectNiche(textLower) {
    const scores = {};
    for (const [niche, kws] of Object.entries(NICHES)) {
      let hits = 0;
      for (const kw of kws) if (textLower.includes(kw)) hits++;
      if (hits > 0) scores[niche] = hits;
    }
    if (Object.keys(scores).length === 0) return "geral";
    return Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0];
  }

  function nicheLabel(n) {
    return ({
      "renda_extra": "💰 Renda Extra",
      "saude_emagrecimento": "🏃 Saúde / Fitness",
      "relacionamento": "💕 Relacionamento",
      "espiritualidade": "🔮 Espiritualidade",
      "geral": "📦 Geral"
    })[n] || "📦 Geral";
  }

  // ---------- CLASSIFICAÇÃO DE TIPO DE OFERTA ----------
  const OFFER_TYPES = {
    "dorama": [
      "dorama","doramas","k-drama","kdrama","k drama","novela coreana","novelas coreanas",
      "novela turca","série coreana","serie coreana","assista doramas","assistir doramas",
      "doramas online","kissasian","viki","iqiyi","wetv","rakuten viki",
      "episódios completos","episodios completos","todos os episódios","todos os episodios",
      "novela completa","filme completo","filmes online","filmes grátis","filmes gratis",
      "serie completa","série completa","temporadas completas","anime online","animes online","assistir anime"
    ],
    "ecommerce": [
      "frete grátis","frete gratis","envio rápido","envio rapido","compre agora","compre já","compre ja","comprar agora",
      "loja oficial","loja online","shopee","mercado livre","amazon","tamanho","tamanhos disponíveis","tamanhos disponiveis",
      "cor","cores disponíveis","cores disponiveis","estoque","últimas unidades","ultimas unidades",
      "pix com desconto","à vista no pix","a vista no pix","12x sem juros","10x sem juros","parcele",
      "tênis","tenis","camisa","camiseta","blusa","vestido","calça","calca",
      "perfume","cosmético","cosmetico","maquiagem","skincare","celular","smartphone","iphone","fone de ouvido","smartwatch",
      "kit completo","combo promocional","rastreio","rastreamento","código de rastreio",
      "garantia de","devolução em","devolucao em","produto original","100% original",
      "leve 3 pague 2","leve 2 pague 1","compre 1 leve","frete fixo","envio para todo brasil","envio para todo o brasil"
    ],
    "digital": [
      "ebook","e-book","pdf","checklist","minicurso","mini curso","curso online","treinamento online",
      "método","metodo","passo a passo","vitalício","vitalicio","acesso vitalício","acesso vitalicio",
      "área de membros","area de membros","área do aluno","area do aluno","acesso imediato","download imediato",
      "hotmart","eduzz","kiwify","monetizze","perfectpay","perfect pay","carga horária","carga horaria",
      "certificado","aulas online","aulas gravadas","comunidade exclusiva","grupo vip",
      "modulo","módulo","módulos","modulos","conteúdo digital","conteudo digital","guia completo em pdf","ebook completo"
    ],
    "servico": [
      "agendar","agendamento","marcar horário","marcar horario","marque sua consulta","consulta","consultório","consultorio",
      "atendimento","atendimento online","atendimento personalizado","advogado","advogada","advocacia","oab",
      "dentista","odontologia","odontológico","odontologico","psicólogo","psicologo","psicóloga","psicologa","terapeuta","terapia",
      "estética","estetica","salão","salao","barbearia","imóvel","imovel","imóveis","imoveis","imobiliária","imobiliaria",
      "construtora","incorporadora","lançamento imobiliário","lancamento imobiliario",
      "encanador","eletricista","pedreiro","pintor","buffet","evento corporativo","festa de","decoração de festa","decoracao de festa",
      "limpeza residencial","diarista","criação de site","criacao de site","desenvolvimento de site","agência digital","agencia digital",
      "consultoria empresarial","tráfego pago para empresas","trafego pago para empresas","transporte","mudança","mudanca",
      "frete de mudança","veterinário","veterinario","clínica veterinária","clinica veterinaria",
      "personal trainer","personal training","viagem","pacote de viagem","passagem aérea","passagem aerea"
    ]
  };

  function classifyOfferType(textLower) {
    const scores = { ecommerce: 0, digital: 0, dorama: 0, servico: 0 };
    for (const [type, kws] of Object.entries(OFFER_TYPES)) {
      for (const kw of kws) if (textLower.includes(kw)) scores[type]++;
    }
    if (scores.dorama >= 1) return { type: "dorama", scores };
    const best = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
    if (!best || best[1] === 0) return { type: "outro", scores };
    return { type: best[0], scores };
  }

  function offerTypeLabel(t) {
    return ({
      "ecommerce": "🛒 E-commerce",
      "digital": "💻 Produto Digital",
      "dorama": "🎭 Dorama/Streaming",
      "servico": "🛠 Serviço",
      "outro": "❓ Outro"
    })[t] || "❓ Outro";
  }

  function detectTriggers(textLower) {
    return TRIGGER_WORDS.filter(w => textLower.includes(w));
  }

  function fingerprintAd(card) {
    const txt = (card.innerText || "").slice(0, 400);
    let h = 0;
    for (let i = 0; i < txt.length; i++) {
      h = ((h << 5) - h) + txt.charCodeAt(i);
      h |= 0;
    }
    return "ad_" + h.toString(36);
  }

  // Fingerprint da COPY (texto normalizado, sem preço/data, primeiros 200 chars)
  // Usado pra detectar variações do MESMO criativo do mesmo anunciante.
  function fingerprintCopy(text) {
    if (!text) return "empty";
    const normalized = text
      .toLowerCase()
      .replace(/r\$\s*\d+[\.,]?\d*/g, "")           // tira preços
      .replace(/\d+/g, "#")                          // tira números (datas, valores)
      .replace(/[^\p{L}#]+/gu, " ")                  // só letras+placeholder
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 200);
    let h = 0;
    for (let i = 0; i < normalized.length; i++) {
      h = ((h << 5) - h) + normalized.charCodeAt(i);
      h |= 0;
    }
    return "cp_" + h.toString(36);
  }

  // Conta quantas variações tem deste anunciante (mesma copy) e total dele
  function getVariationStats(ad) {
    if (!ad) return { sameAdvertiser: 0, sameCopy: 0 };
    let sameAdvertiser = 0;
    let sameCopy = 0;
    if (ad.advertiser) {
      const set = adsByAdvertiser.get(ad.advertiser);
      if (set) sameAdvertiser = set.size;
    }
    if (ad.copyFp) {
      const set = adsByCopyFp.get(ad.copyFp);
      if (set) sameCopy = set.size;
    }
    return { sameAdvertiser, sameCopy };
  }

  // ---------- DETECÇÃO DE DATA / DIAS RODANDO ----------
  function extractStartDate(text) {
    if (!text) return null;

    const ptRe = /(?:veicula[cç][ãa]o\s+iniciada\s+em|iniciou\s+a\s+veicula[cç][ãa]o\s+em|em\s+veicula[cç][ãa]o\s+desde)\s+(\d{1,2})\s+de\s+([a-zçãéí]+)\.?\s+de\s+(\d{4})/i;
    let m = text.match(ptRe);
    if (m) {
      const day = parseInt(m[1], 10);
      const monKey = m[2].toLowerCase().replace(".", "");
      const month = MONTHS_PT[monKey];
      const year = parseInt(m[3], 10);
      if (!isNaN(day) && month != null && !isNaN(year)) return new Date(year, month, day);
    }

    const ptShortRe = /(?:veicula[cç][ãa]o\s+iniciada\s+em|iniciou\s+a\s+veicula[cç][ãa]o\s+em)\s+(\d{1,2})\/(\d{1,2})\/(\d{4})/i;
    m = text.match(ptShortRe);
    if (m) {
      const d = new Date(parseInt(m[3]), parseInt(m[2])-1, parseInt(m[1]));
      if (!isNaN(d.getTime())) return d;
    }

    const enRe = /started\s+running\s+on\s+([a-z]+)\.?\s+(\d{1,2}),?\s+(\d{4})/i;
    m = text.match(enRe);
    if (m) {
      const monKey = m[1].toLowerCase().replace(".", "");
      const month = MONTHS_EN[monKey];
      const day = parseInt(m[2], 10);
      const year = parseInt(m[3], 10);
      if (!isNaN(day) && month != null && !isNaN(year)) return new Date(year, month, day);
    }

    return null;
  }

  function daysBetween(date) {
    if (!date) return null;
    const ms = new Date().getTime() - date.getTime();
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));
    return days >= 0 ? days : null;
  }

  // ---------- DETECÇÃO DE LP ----------
  function extractLandingPage(card) {
    const links = card.querySelectorAll("a[href]");
    const externalDomains = [];
    for (const a of links) {
      let href = a.getAttribute("href") || "";
      if (!href) continue;
      if (href.startsWith("https://l.facebook.com/l.php") || href.startsWith("https://lm.facebook.com/l.php") || href.includes("/l.php?u=")) {
        try {
          const u = new URL(href, location.href);
          const real = u.searchParams.get("u");
          if (real) {
            const decoded = decodeURIComponent(real);
            if (!/facebook\.com|fbcdn\.net|instagram\.com/i.test(decoded)) {
              externalDomains.push(decoded);
              continue;
            }
          }
        } catch (e) {}
      }
      if (/^https?:\/\//i.test(href) && !/facebook\.com|fbcdn\.net|instagram\.com|messenger\.com/i.test(href)) {
        externalDomains.push(href);
      }
    }
    return externalDomains[0] || null;
  }

  // ---------- DETECÇÃO DE VÍDEO ----------
  // Decodifica URLs do Meta (\/ e \u00XX)
  function decodeMetaUrl(s) {
    if (!s) return s;
    return s.replace(/\\\//g, "/").replace(/\\u([0-9a-fA-F]{4})/g, (_m, h) => String.fromCharCode(parseInt(h, 16)));
  }

  // Cache de URLs encontradas nos scripts da página, indexadas pelo ID do vídeo
  const _videoUrlCache = new Map();   // videoId → { hd, sd }
  let _lastScriptScanTime = 0;

  // Patterns de URL do Meta (mesmos que yt-dlp usa)
  const HD_PATTERNS = [
    /"browser_native_hd_url":"([^"]+\.mp4[^"]*)"/g,
    /"playable_url_quality_hd":"([^"]+\.mp4[^"]*)"/g,
    /"playable_url_quality_hd_url":"([^"]+\.mp4[^"]*)"/g,
    /"hd_src":"([^"]+\.mp4[^"]*)"/g,
    /"hd_src_no_ratelimit":"([^"]+\.mp4[^"]*)"/g,
    /"original_video_url":"([^"]+\.mp4[^"]*)"/g
  ];
  const SD_PATTERNS = [
    /"browser_native_sd_url":"([^"]+\.mp4[^"]*)"/g,
    /"playable_url":"([^"]+\.mp4[^"]*)"/g,
    /"sd_src":"([^"]+\.mp4[^"]*)"/g,
    /"sd_src_no_ratelimit":"([^"]+\.mp4[^"]*)"/g
  ];

  // Extrai o "video ID" da URL do CDN (números longos no path)
  function extractVideoId(url) {
    if (!url) return null;
    // /t42.1790-2/.../<NUMEROS>_<NUMEROS>_<NUMEROS>_n.mp4
    const m1 = url.match(/\/(\d{8,})_(\d{8,})_(\d{6,})_n\.mp4/);
    if (m1) return m1[1] + "_" + m1[2];
    const m2 = url.match(/[?&]v=(\d{10,})/);
    if (m2) return m2[1];
    const m3 = url.match(/\/(\d{12,})/);
    if (m3) return m3[1];
    return null;
  }

  // Varre todos os scripts da página e popula o cache
  function scanPageForVideoUrls(force) {
    const now = Date.now();
    if (!force && (now - _lastScriptScanTime) < 1500) return;
    _lastScriptScanTime = now;

    let combined = "";
    try {
      const scripts = document.querySelectorAll("script:not([src])");
      for (const s of scripts) {
        const t = s.textContent;
        if (!t || t.length < 80) continue;
        if (t.length > 2000000) continue;       // pula scripts gigantes
        if (!t.includes(".mp4")) continue;       // só os que mencionam mp4
        combined += t + "\n";
      }
    } catch (e) { WARN("scan scripts:", e); return; }
    if (!combined) return;

    const found = { hd: 0, sd: 0 };
    const indexUrl = (url, qual) => {
      const id = extractVideoId(url);
      if (!id) return;
      let entry = _videoUrlCache.get(id);
      if (!entry) { entry = { hd: null, sd: null }; _videoUrlCache.set(id, entry); }
      if (qual === "hd" && !entry.hd) { entry.hd = url; found.hd++; }
      else if (qual === "sd" && !entry.sd) { entry.sd = url; found.sd++; }
    };

    for (const re of HD_PATTERNS) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(combined)) !== null) indexUrl(decodeMetaUrl(m[1]), "hd");
    }
    for (const re of SD_PATTERNS) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(combined)) !== null) indexUrl(decodeMetaUrl(m[1]), "sd");
    }

    if (found.hd > 0 || found.sd > 0) {
      LOG(`URLs descobertas: +${found.hd} HD · +${found.sd} SD (cache: ${_videoUrlCache.size})`);
    }
  }

  // Procura a melhor URL pra um vídeo dado o src atual do <video>
  function findBestVideoUrl(currentSrc) {
    scanPageForVideoUrls();
    if (currentSrc && currentSrc.startsWith("blob:")) return null;
    if (currentSrc) {
      const id = extractVideoId(currentSrc);
      if (id && _videoUrlCache.has(id)) {
        const e = _videoUrlCache.get(id);
        if (e.hd) return { url: e.hd, quality: "hd" };
        if (e.sd) return { url: e.sd, quality: "sd" };
      }
    }
    return null;
  }

  function extractVideo(card) {
    const v = card.querySelector("video");
    if (!v) return null;
    let src = v.currentSrc || v.src || "";
    if (!src) {
      const s = v.querySelector("source");
      if (s) src = s.src || s.getAttribute("src") || "";
    }
    if (!src) return null;

    // Tenta achar uma versão melhor (HD) nos scripts
    let bestUrl = src;
    let quality = src.startsWith("blob:") ? "blob" : "sd";
    const better = findBestVideoUrl(src);
    if (better) {
      bestUrl = better.url;
      quality = better.quality;
    }
    return {
      src: bestUrl,            // melhor URL disponível
      originalSrc: src,         // o que estava no player
      quality,                  // "hd" | "sd" | "blob"
      isBlob: bestUrl.startsWith("blob:"),
      poster: v.poster || null
    };
  }

  // ---------- SCORE VIRAL (0-100) ----------
  // Combina sinais que indicam que um anúncio está vendendo / escalando.
  function computeViralScore({ ticketClass, daysRunning, triggers, video, landingPage, guaranteeDays }) {
    let score = 0;
    // Dias rodando (max 40 pts)
    if (daysRunning != null) {
      if (daysRunning >= 30) score += 40;
      else if (daysRunning >= 14) score += 30;
      else if (daysRunning >= 7) score += 20;
      else if (daysRunning >= 3) score += 10;
    }
    // Preço low ticket (max 20 pts)
    if (ticketClass === "low") score += 20;
    else if (ticketClass === "mid") score += 8;
    // Tem vídeo (10 pts)
    if (video) score += 10;
    // Tem LP (10 pts)
    if (landingPage) score += 10;
    // Garantia (5 pts)
    if (guaranteeDays && guaranteeDays > 0) score += 5;
    // Gatilhos (max 15 pts — 3 por gatilho até 5)
    const tCount = triggers ? Math.min(triggers.length, 5) : 0;
    score += tCount * 3;
    return Math.min(100, score);
  }

  function viralBand(score) {
    if (score >= 75) return { band: "fire", label: "🔥 ESCALANDO" };
    if (score >= 55) return { band: "hot",  label: "🚀 PROMISSOR" };
    if (score >= 35) return { band: "warm", label: "⚡ OK" };
    return { band: "cold", label: "❄️ FRACO" };
  }

  // ---------- ANÁLISE DE UM CARD ----------
  function analyzeCard(card) {
    if (processedAds.has(card)) return null;
    processedAds.add(card);

    const text = card.innerText || "";
    if (text.length < 30) return null;

    const textLower = text.toLowerCase();
    const prices = extractPrices(text);
    const triggers = detectTriggers(textLower);
    const startDate = extractStartDate(text);
    const daysRunning = daysBetween(startDate);
    const landingPage = extractLandingPage(card);
    const video = extractVideo(card);

    if (prices.length === 0 && triggers.length === 0 && !startDate && !video) return null;

    const sortedPrices = prices.slice().sort((a, b) => a.value - b.value);
    const mainPrice = sortedPrices[0];
    const ticketClass = mainPrice ? classifyTicket(mainPrice.value) : null;
    const niche = detectNiche(textLower);
    const { type: offerType, scores: offerScores } = classifyOfferType(textLower);
    const platform = detectPlatform(landingPage, textLower);
    const guaranteeDays = detectGuarantee(text);
    const viralScore = computeViralScore({
      ticketClass, daysRunning, triggers, video, landingPage, guaranteeDays
    });

    let advertiser = "";
    const strongEl = card.querySelector("strong, h3, h2, a[role='link']");
    if (strongEl) advertiser = strongEl.innerText.trim().slice(0, 80);

    const fp = fingerprintAd(card);
    const copyFp = fingerprintCopy(text);

    return {
      id: fp,
      copyFp,
      advertiser,
      price: mainPrice ? mainPrice.value : null,
      priceRaw: mainPrice ? mainPrice.raw : null,
      allPrices: prices.map(p => p.value),
      ticketClass,
      niche,
      offerType,
      offerScores,
      platform,
      triggers,
      guaranteeDays,
      viralScore,
      startDate: startDate ? startDate.toISOString() : null,
      daysRunning,
      landingPage,
      hasVideo: !!video,
      videoSrc: video ? video.src : null,
      videoOriginalSrc: video ? video.originalSrc : null,
      videoQuality: video ? video.quality : null,
      videoIsBlob: video ? video.isBlob : false,
      videoPoster: video ? video.poster : null,
      fullText: text.slice(0, 2000),
      snippet: text.slice(0, 240).replace(/\s+/g, " "),
      capturedAt: new Date().toISOString()
    };
  }

  // ---------- DETECÇÃO DE CARDS ----------
  function findAdCards(root = document) {
    const markers = [
      "Identificação da biblioteca", "Identificador da biblioteca", "Library ID",
      "Veiculação iniciada em", "Iniciou a veiculação", "Started running on"
    ];
    const candidates = new Set();
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const t = node.nodeValue;
        if (!t || t.length < 5) return NodeFilter.FILTER_REJECT;
        for (const m of markers) if (t.includes(m)) return NodeFilter.FILTER_ACCEPT;
        return NodeFilter.FILTER_REJECT;
      }
    });
    let node;
    while ((node = walker.nextNode())) {
      let el = node.parentElement;
      let depth = 0;
      while (el && depth < 12) {
        const r = el.getBoundingClientRect();
        if (r.height >= 200 && r.width >= 250) {
          candidates.add(el);
          break;
        }
        el = el.parentElement;
        depth++;
      }
    }
    return Array.from(candidates);
  }

  // ---------- VISUAL ----------
  function decorateCard(card, data) {
    if (!data) return;
    card.classList.add("lth-scanned");
    card.dataset.lthId = data.id;
    card.dataset.lthDays = data.daysRunning != null ? data.daysRunning : "";

    if (data.ticketClass === "low") card.classList.add("lth-low");
    else if (data.ticketClass === "mid") card.classList.add("lth-mid");
    else if (data.ticketClass === "high") card.classList.add("lth-high");

    if (card.querySelector(".lth-badge-wrap")) return;

    const wrap = document.createElement("div");
    wrap.className = "lth-badge-wrap";

    if (data.ticketClass === "low") {
      const b = document.createElement("div");
      b.className = "lth-badge lth-badge-low";
      b.textContent = `🎯 LOW TICKET${data.priceRaw ? " · " + data.priceRaw : ""}`;
      wrap.appendChild(b);
    } else if (data.ticketClass === "mid") {
      const b = document.createElement("div");
      b.className = "lth-badge lth-badge-mid";
      b.textContent = `⚡ MID${data.priceRaw ? " · " + data.priceRaw : ""}`;
      wrap.appendChild(b);
    } else if (data.ticketClass === "high") {
      const b = document.createElement("div");
      b.className = "lth-badge lth-badge-high";
      b.textContent = `💎 HIGH${data.priceRaw ? " · " + data.priceRaw : ""}`;
      wrap.appendChild(b);
    }

    if (data.daysRunning != null && data.daysRunning >= 0) {
      const d = document.createElement("div");
      let cls = "lth-days";
      let icon = "📅";
      if (data.daysRunning >= 30) { cls += " lth-days-fire"; icon = "🔥🔥"; }
      else if (data.daysRunning >= 7) { cls += " lth-days-hot"; icon = "🔥"; }
      else if (data.daysRunning >= 3) { cls += " lth-days-warm"; }
      d.className = cls;
      d.textContent = `${icon} ${data.daysRunning} ${data.daysRunning === 1 ? "dia" : "dias"} rodando`;
      wrap.appendChild(d);
    }

    // Score viral
    if (data.viralScore != null) {
      const v = viralBand(data.viralScore);
      const s = document.createElement("div");
      s.className = "lth-score lth-score-" + v.band;
      s.textContent = `${v.label} · ${data.viralScore}`;
      s.title = `Score viral: ${data.viralScore}/100`;
      wrap.appendChild(s);
    }

    // Tipo de oferta
    if (data.offerType) {
      const t = document.createElement("div");
      t.className = "lth-type lth-type-" + data.offerType;
      t.textContent = offerTypeLabel(data.offerType);
      wrap.appendChild(t);
    }

    // Plataforma
    if (data.platform) {
      const p = document.createElement("div");
      p.className = "lth-platform";
      p.textContent = platformLabel(data.platform);
      wrap.appendChild(p);
    }

    // Garantia
    if (data.guaranteeDays && data.guaranteeDays > 0) {
      const g = document.createElement("div");
      g.className = "lth-guarantee";
      g.textContent = `🛡 ${data.guaranteeDays}d garantia`;
      wrap.appendChild(g);
    }

    // Qualidade do vídeo (HD/SD)
    if (data.hasVideo && data.videoQuality) {
      const q = document.createElement("div");
      q.className = "lth-quality lth-quality-" + data.videoQuality;
      q.textContent = data.videoQuality === "hd" ? "🎬 HD"
                   : data.videoQuality === "sd" ? "🎬 SD"
                   : "🎬 stream";
      q.title = data.videoQuality === "hd"
        ? "Versão HD detectada nos scripts da página"
        : data.videoQuality === "sd"
        ? "Apenas versão SD encontrada"
        : "Stream sem URL HD direta (será capturado o que o player carregou)";
      wrap.appendChild(q);
    }

    // Badge de variações (atualizado depois em refreshVariationBadges)
    const variation = document.createElement("div");
    variation.className = "lth-variation";
    variation.dataset.lthAdv = data.advertiser || "";
    variation.dataset.lthCopy = data.copyFp || "";
    variation.textContent = "🔁 ...";
    variation.title = "Clique pra ver só este anunciante";
    variation.style.cursor = "pointer";
    variation.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!data.advertiser) return;
      if (advertiserFilter === data.advertiser) {
        advertiserFilter = null;
        showToast("✋ Filtro de anunciante removido");
      } else {
        advertiserFilter = data.advertiser;
        showToast(`🔁 Só "${data.advertiser}"`);
      }
      applyFilter();
    });
    wrap.appendChild(variation);

    if (data.niche && data.niche !== "geral") {
      const n = document.createElement("div");
      n.className = "lth-niche";
      n.textContent = nicheLabel(data.niche);
      wrap.appendChild(n);
    }

    if (data.triggers && data.triggers.length > 0) {
      const t = document.createElement("div");
      t.className = "lth-triggers";
      t.textContent = "🔥 " + data.triggers.slice(0, 3).join(" · ");
      wrap.appendChild(t);
    }

    const actions = document.createElement("div");
    actions.className = "lth-actions-row";

    if (data.ticketClass === "low") {
      const save = document.createElement("button");
      save.className = "lth-act-btn lth-act-save";
      save.textContent = "⭐ Salvar";
      save.title = "Salvar nos favoritos";
      save.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        chrome.runtime.sendMessage({ type: "SAVE_AD", data }, (resp) => {
          if (resp && resp.ok) {
            save.textContent = "✓ Salvo";
            save.classList.add("lth-saved");
          }
        });
      });
      actions.appendChild(save);
    }

    if (data.landingPage) {
      const lp = document.createElement("button");
      lp.className = "lth-act-btn lth-act-lp";
      lp.textContent = "🔗 Ir para LP";
      lp.title = "Abrir landing page em nova aba\n" + data.landingPage;
      lp.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        window.open(data.landingPage, "_blank", "noopener,noreferrer");
      });
      actions.appendChild(lp);
    }

    if (data.hasVideo) {
      const dl = document.createElement("button");
      dl.className = "lth-act-btn lth-act-video";
      dl.textContent = "📥 Baixar vídeo";
      dl.title = "Baixar o vídeo deste anúncio";
      dl.addEventListener("click", async (e) => {
        e.preventDefault(); e.stopPropagation();
        await downloadVideo(card, data, dl);
      });
      actions.appendChild(dl);
    }

    // Botão copiar texto
    const cp = document.createElement("button");
    cp.className = "lth-act-btn lth-act-copy";
    cp.textContent = "📋 Copiar";
    cp.title = "Copiar texto completo do anúncio";
    cp.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      try {
        await navigator.clipboard.writeText(data.fullText || data.snippet || "");
        cp.textContent = "✓ Copiado";
        setTimeout(() => { cp.textContent = "📋 Copiar"; }, 1500);
      } catch (err) {
        cp.textContent = "✗ Erro";
        setTimeout(() => { cp.textContent = "📋 Copiar"; }, 1500);
      }
    });
    actions.appendChild(cp);

    // Botão baixar ZIP completo do anúncio
    const zb = document.createElement("button");
    zb.className = "lth-act-btn lth-act-zip";
    zb.textContent = "📦 ZIP";
    zb.title = "Baixar pacote ZIP completo: copy + imagens + vídeo + landing page + metadados";
    zb.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      zb.disabled = true;
      await downloadAdAsZip(card, data, zb);
      zb.disabled = false;
    });
    actions.appendChild(zb);

    // Botões de HTML da LP (só se tiver LP)
    if (data.landingPage) {
      // Copiar HTML
      const hc = document.createElement("button");
      hc.className = "lth-act-btn lth-act-htmlcopy";
      hc.textContent = "📄 Copiar HTML";
      hc.title = "Copia o HTML inteiro da landing page pro clipboard";
      hc.addEventListener("click", async (e) => {
        e.preventDefault(); e.stopPropagation();
        hc.disabled = true;
        hc.textContent = "⏳...";
        try {
          const r = await fetchViaBg(data.landingPage);
          if (r && r.ok && r.dataB64) {
            const html = new TextDecoder("utf-8").decode(b64ToBytes(r.dataB64));
            await navigator.clipboard.writeText(html);
            hc.textContent = `✓ ${(html.length / 1024).toFixed(0)} KB`;
          } else {
            hc.textContent = "✗ Erro";
          }
        } catch (err) {
          ERR("copiar HTML:", err);
          hc.textContent = "✗ Erro";
        }
        setTimeout(() => { hc.textContent = "📄 Copiar HTML"; hc.disabled = false; }, 2500);
      });
      actions.appendChild(hc);

      // Baixar HTML
      const hs = document.createElement("button");
      hs.className = "lth-act-btn lth-act-htmlsave";
      hs.textContent = "💾 .html";
      hs.title = "Baixar o HTML da landing page como arquivo .html";
      hs.addEventListener("click", async (e) => {
        e.preventDefault(); e.stopPropagation();
        hs.disabled = true;
        hs.textContent = "⏳...";
        try {
          const r = await fetchViaBg(data.landingPage);
          if (r && r.ok && r.dataB64) {
            const bytes = b64ToBytes(r.dataB64);
            const blob = new Blob([bytes], { type: r.contentType || "text/html;charset=utf-8" });
            const url = URL.createObjectURL(blob);
            const ext = pickExt(data.landingPage, r.contentType) || "html";
            const fname = `lp_${safeFilename(data.advertiser)}_${data.id}.${ext}`;
            const a = document.createElement("a");
            a.href = url;
            a.download = fname;
            document.body.appendChild(a);
            a.click();
            setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1500);
            hs.textContent = "✓ Salvo";
          } else {
            hs.textContent = "✗ Erro";
          }
        } catch (err) {
          ERR("salvar HTML:", err);
          hs.textContent = "✗ Erro";
        }
        setTimeout(() => { hs.textContent = "💾 .html"; hs.disabled = false; }, 2500);
      });
      actions.appendChild(hs);
    }

    if (actions.children.length > 0) wrap.appendChild(actions);

    const cs = getComputedStyle(card);
    if (cs.position === "static") card.style.position = "relative";
    card.appendChild(wrap);
  }

  // ---------- DOWNLOAD DE VÍDEO ----------
  async function downloadVideo(card, data, btn) {
    btn.textContent = "⏳ Baixando...";
    btn.disabled = true;
    try {
      // Re-escaneia scripts agora (pode ter mais URLs carregadas)
      try { scanPageForVideoUrls(true); } catch (e) {}

      const v = card.querySelector("video");
      let originalSrc = v ? (v.currentSrc || v.src) : (data.videoOriginalSrc || data.videoSrc);
      if (!originalSrc && v) {
        const s = v.querySelector("source");
        if (s) originalSrc = s.src || s.getAttribute("src");
      }

      let src = originalSrc;
      let quality = (src && src.startsWith("blob:")) ? "blob" : (data.videoQuality || "sd");

      // Tenta upgrade pra HD
      const better = findBestVideoUrl(originalSrc);
      if (better) {
        src = better.url;
        quality = better.quality;
        LOG(`upgrade vídeo → ${quality}`);
      } else if (data.videoSrc && data.videoSrc !== originalSrc && !data.videoSrc.startsWith("blob:")) {
        src = data.videoSrc;
        quality = data.videoQuality || "sd";
      }

      if (!src) {
        btn.textContent = "❌ Sem fonte";
        setTimeout(() => { btn.textContent = "📥 Baixar vídeo"; btn.disabled = false; }, 2000);
        return;
      }

      btn.textContent = quality === "hd" ? "⏳ HD..." : quality === "sd" ? "⏳ SD..." : "⏳ Baixando...";

      const qSuffix = quality === "hd" ? "_HD" : quality === "sd" ? "_SD" : "";
      const filename = `meta-ad_${(data.advertiser || "anuncio").replace(/[^a-z0-9]/gi, "_").slice(0, 40)}_${data.id}${qSuffix}.mp4`;

      if (src.startsWith("blob:")) {
        try {
          const resp = await fetch(src);
          const blob = await resp.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1500);
          btn.textContent = "✓ Baixado";
        } catch (err) {
          window.open(src, "_blank");
          btn.textContent = "↗ Aberto";
        }
      } else if (/^https?:/i.test(src)) {
        // Faz o fetch direto no content script (roda em facebook.com → Referer automático)
        // Evita o bloqueio do CDN que ocorre quando o service worker tenta baixar sem Referer
        try {
          btn.textContent = "⏳ Baixando...";
          const resp = await fetch(src, { credentials: "omit" });
          if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
          const blob = await resp.blob();
          const blobUrl = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = blobUrl;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => { URL.revokeObjectURL(blobUrl); a.remove(); }, 2000);
          btn.textContent = "✓ Baixado";
        } catch (fetchErr) {
          ERR("fetch direto falhou, tentando background:", fetchErr);
          chrome.runtime.sendMessage({ type: "DOWNLOAD_VIDEO", url: src, filename }, (resp) => {
            btn.textContent = resp?.ok ? "✓ Baixado" : "❌ Erro ao baixar";
          });
        }
      } else {
        btn.textContent = "❌ URL inválida";
      }
    } catch (err) {
      console.error("[LTH] download err:", err);
      btn.textContent = "❌ Erro";
    } finally {
      setTimeout(() => {
        btn.textContent = "📥 Baixar vídeo";
        btn.disabled = false;
      }, 3000);
    }
  }

  // ---------- COLETA DE ASSETS DO CARD ----------
  function collectImages(card) {
    const imgs = card.querySelectorAll("img");
    const seen = new Set();
    const out = [];
    for (const img of imgs) {
      const src = img.currentSrc || img.src;
      if (!src) continue;
      if (seen.has(src)) continue;
      seen.add(src);
      // Pula avatars muito pequenos e emojis
      const r = img.getBoundingClientRect();
      if (r.width < 60 || r.height < 60) continue;
      if (/static\.xx\.fbcdn\.net\/rsrc\.php/.test(src)) continue; // ícones do Facebook
      if (/emoji/i.test(src)) continue;
      out.push({ src, w: r.width, h: r.height, alt: img.alt || "" });
    }
    return out;
  }

  async function fetchViaBg(url) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: "FETCH_URL", url }, (resp) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: String(chrome.runtime.lastError) });
            return;
          }
          resolve(resp || { ok: false, error: "sem resposta" });
        });
      } catch (e) {
        resolve({ ok: false, error: String(e) });
      }
    });
  }

  function b64ToBytes(b64) {
    const bin = atob(b64);
    const len = bin.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  function pickExt(url, contentType) {
    if (contentType) {
      const m = contentType.match(/^([a-z]+)\/([a-z0-9.+\-]+)/i);
      if (m) {
        const sub = m[2].toLowerCase().split(";")[0];
        if (sub === "jpeg") return "jpg";
        if (sub === "html") return "html";
        return sub.replace(/^x-/, "");
      }
    }
    try {
      const u = new URL(url, location.href);
      const p = u.pathname.match(/\.([a-z0-9]{2,5})$/i);
      if (p) return p[1].toLowerCase();
    } catch (e) {}
    return "bin";
  }

  function safeFilename(s, fallback = "anuncio") {
    if (!s) return fallback;
    return String(s)
      .replace(/[^\p{L}\p{N}._-]+/gu, "_")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "")
      .slice(0, 60) || fallback;
  }

  // ---------- DOWNLOAD ZIP COMPLETO DO ANÚNCIO ----------
  async function downloadAdAsZip(card, data, btn) {
    if (typeof MiniZip === "undefined") {
      WARN("MiniZip não carregado");
      if (btn) btn.textContent = "❌ ZIP indisponível";
      return;
    }
    const setBtn = (t) => { if (btn) btn.textContent = t; };
    setBtn("⏳ Coletando...");

    const files = [];
    const log = [];

    // 1. info.json
    files.push({ name: "info.json", data: JSON.stringify(data, null, 2) });
    log.push("info.json");

    // 2. copy.txt
    const copyText = data.fullText || data.snippet || "";
    if (copyText) {
      files.push({ name: "copy.txt", data: copyText });
      log.push("copy.txt");
    }

    // 3. Imagens
    setBtn("⏳ Imagens...");
    const imgs = collectImages(card);
    for (let i = 0; i < Math.min(imgs.length, 8); i++) {
      const im = imgs[i];
      const r = await fetchViaBg(im.src);
      if (r && r.ok && r.dataB64) {
        const ext = pickExt(im.src, r.contentType) || "jpg";
        files.push({ name: `imagens/img-${i + 1}.${ext}`, data: b64ToBytes(r.dataB64) });
        log.push(`imagens/img-${i + 1}.${ext}`);
      }
    }

    // 4. Vídeo (preferindo HD)
    if (data.hasVideo) {
      setBtn("⏳ Vídeo...");
      try {
        scanPageForVideoUrls(true);
        const better = findBestVideoUrl(data.videoOriginalSrc || data.videoSrc);
        const videoUrl = better ? better.url : data.videoSrc;
        const quality = better ? better.quality : (data.videoQuality || "sd");
        if (videoUrl) {
          const qSuffix = quality === "hd" ? "_HD" : "_SD";
          if (videoUrl.startsWith("blob:")) {
            const blob = await (await fetch(videoUrl)).blob();
            const buf = await blob.arrayBuffer();
            files.push({ name: `video${qSuffix}.mp4`, data: new Uint8Array(buf) });
            log.push(`video${qSuffix}.mp4 (blob)`);
          } else {
            const r = await fetchViaBg(videoUrl);
            if (r && r.ok && r.dataB64) {
              files.push({ name: `video${qSuffix}.mp4`, data: b64ToBytes(r.dataB64) });
              log.push(`video${qSuffix}.mp4 (cdn, ${(r.size/1024/1024).toFixed(1)} MB)`);
            }
          }
        }
      } catch (e) {
        WARN("vídeo falhou:", e);
      }
    }

    // 5. Landing page HTML
    if (data.landingPage) {
      setBtn("⏳ LP...");
      const r = await fetchViaBg(data.landingPage);
      if (r && r.ok && r.dataB64) {
        const ext = pickExt(data.landingPage, r.contentType) || "html";
        files.push({ name: `landing-page.${ext}`, data: b64ToBytes(r.dataB64) });
        log.push(`landing-page.${ext}`);
        // Salva URL final (após redirects) num arquivo separado
        if (r.finalUrl && r.finalUrl !== data.landingPage) {
          files.push({ name: "landing-page-url.txt", data: `Original: ${data.landingPage}\nFinal:    ${r.finalUrl}\n` });
        }
      } else {
        files.push({ name: "landing-page-erro.txt", data: `URL: ${data.landingPage}\nErro: ${r ? r.error : 'desconhecido'}\n` });
      }
    }

    // 6. README
    const readme =
      `Anúncio capturado pela extensão Hunter X\n\n` +
      `Anunciante: ${data.advertiser || "?"}\n` +
      `Preço:      ${data.priceRaw || (data.price != null ? "R$ " + data.price.toFixed(2) : "?")}\n` +
      `Tipo:       ${data.offerType || "?"}\n` +
      `Plataforma: ${data.platform || "?"}\n` +
      `Dias rodando: ${data.daysRunning != null ? data.daysRunning : "?"}\n` +
      `Score viral: ${data.viralScore != null ? data.viralScore + "/100" : "?"}\n` +
      `Garantia: ${data.guaranteeDays ? data.guaranteeDays + " dias" : "—"}\n` +
      `Landing page: ${data.landingPage || "—"}\n\n` +
      `Conteúdo do ZIP:\n  ${log.join("\n  ")}\n\n` +
      `Capturado em: ${data.capturedAt}\n`;
    files.push({ name: "README.txt", data: readme });

    setBtn("⏳ Gerando ZIP...");
    try {
      const zipBytes = MiniZip.create(files);
      const blob = new Blob([zipBytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const fname = `anuncio_${safeFilename(data.advertiser)}_${data.id}.zip`;
      const a = document.createElement("a");
      a.href = url;
      a.download = fname;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 2000);
      setBtn("✓ ZIP salvo");
      LOG(`ZIP "${fname}" gerado com ${files.length} arquivos (${(zipBytes.length/1024).toFixed(0)} KB)`);
    } catch (e) {
      ERR("erro gerando ZIP:", e);
      setBtn("❌ Erro");
    }
    setTimeout(() => setBtn("📦 ZIP"), 3000);
  }

  // ---------- FILTRO ----------
  function applyFilter() {
    document.querySelectorAll(".lth-scanned").forEach(c => {
      const id = c.dataset.lthId;
      const ad = id ? detectedAds.get(id) : null;
      const days = parseInt(c.dataset.lthDays || "-1", 10);
      const type = c.dataset.lthType || "outro";
      const ticket = ad ? ad.ticketClass : null;
      const vs = ad ? (ad.viralScore || 0) : 0;
      const adv = ad ? ad.advertiser : null;

      const failsDays   = (minDaysFilter > 0) && (isNaN(days) || days < minDaysFilter);
      const failsType   = !typeFilter[type];
      const failsTicket = onlyLowTicket && ticket !== "low";
      const failsScore  = (minViralScore > 0) && (vs < minViralScore);
      const failsAdv    = advertiserFilter && adv !== advertiserFilter;

      if (failsDays || failsType || failsTicket || failsScore || failsAdv) {
        c.classList.add("lth-hidden");
      } else {
        c.classList.remove("lth-hidden");
      }
    });
    // Atualiza o indicador do HUD se houver filtro de anunciante ativo
    const advBar = document.getElementById("lth-adv-filter-bar");
    if (advBar) {
      if (advertiserFilter) {
        advBar.style.display = "flex";
        const lbl = document.getElementById("lth-adv-filter-name");
        if (lbl) lbl.textContent = advertiserFilter;
      } else {
        advBar.style.display = "none";
      }
    }
  }

  // Atualiza os badges "🔁 X variações" depois que o indexamento terminou
  function refreshVariationBadges() {
    document.querySelectorAll(".lth-variation").forEach(el => {
      const adv = el.dataset.lthAdv;
      const cp  = el.dataset.lthCopy;
      const totalAdv = adv ? (adsByAdvertiser.get(adv)?.size || 0) : 0;
      const totalCopy = cp ? (adsByCopyFp.get(cp)?.size || 0) : 0;
      if (totalAdv <= 1 && totalCopy <= 1) {
        el.style.display = "none";
        return;
      }
      el.style.display = "";
      const parts = [];
      if (totalAdv > 1) parts.push(`${totalAdv} do anunciante`);
      if (totalCopy > 1) parts.push(`${totalCopy} mesma copy`);
      el.textContent = "🔁 " + parts.join(" · ");
      if (totalCopy >= 5 || totalAdv >= 10) el.classList.add("lth-variation-hot");
      else el.classList.remove("lth-variation-hot");
    });
  }

  function syncToggleUI() {
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.checked = !!v; };
    set("lth-tg-ecom",    typeFilter.ecommerce);
    set("lth-tg-digital", typeFilter.digital);
    set("lth-tg-outro",   typeFilter.outro);
    set("lth-tg-serv",    typeFilter.servico);
    set("lth-tg-dor",     typeFilter.dorama);
    set("lth-tg-onlylow", onlyLowTicket);
    set("lth-tg-autoscroll", autoScrollActive);
    const sv = document.getElementById("lth-min-score-val");
    const sr = document.getElementById("lth-min-score");
    if (sv) sv.textContent = minViralScore;
    if (sr) sr.value = minViralScore;
  }

  function setTypeFilter(key, value) {
    typeFilter[key] = !!value;
    applyFilter();
    updateHud();
    try { chrome.storage.local.set({ typeFilter }); } catch (e) {}
  }

  function setOnlyLow(value) {
    onlyLowTicket = !!value;
    applyFilter();
    try { chrome.storage.local.set({ onlyLowTicket }); } catch (e) {}
  }

  function setMinScore(value) {
    minViralScore = parseInt(value, 10) || 0;
    applyFilter();
    const sv = document.getElementById("lth-min-score-val");
    if (sv) sv.textContent = minViralScore;
    try { chrome.storage.local.set({ minViralScore }); } catch (e) {}
  }

  // ---------- AUTO-SCROLL ----------
  function startAutoScroll() {
    if (autoScrollTimer) return;
    autoScrollActive = true;
    let lastY = -1;
    let stagnant = 0;
    autoScrollTimer = setInterval(() => {
      if (!autoScrollActive) { stopAutoScroll(); return; }
      const cur = window.scrollY;
      window.scrollBy({ top: 600, behavior: "smooth" });
      // Detecta se chegou no fim (scrollY não muda) e pausa
      if (cur === lastY) {
        stagnant++;
        if (stagnant >= 4) {
          stopAutoScroll();
          showToast("✋ Auto-scroll pausado — chegou no final");
        }
      } else {
        stagnant = 0;
      }
      lastY = cur;
    }, 1200);
  }

  function stopAutoScroll() {
    autoScrollActive = false;
    if (autoScrollTimer) { clearInterval(autoScrollTimer); autoScrollTimer = null; }
    const cb = document.getElementById("lth-tg-autoscroll");
    if (cb) cb.checked = false;
  }

  function toggleAutoScroll() {
    if (autoScrollActive) stopAutoScroll();
    else startAutoScroll();
  }

  function showToast(msg) {
    const t = document.createElement("div");
    t.className = "lth-toast";
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add("lth-toast-show"), 10);
    setTimeout(() => {
      t.classList.remove("lth-toast-show");
      setTimeout(() => t.remove(), 300);
    }, 2500);
  }

  // ---------- VARREDURA ----------
  function scan() {
    scanCount++;
    let cards = [];
    try {
      cards = findAdCards();
    } catch (e) {
      ERR("findAdCards falhou:", e);
      return;
    }
    LOG(`scan #${scanCount}: ${cards.length} cards encontrados`);
    let newLow = 0, newMid = 0, newHigh = 0, failed = 0;
    for (const card of cards) {
      try {
        const data = analyzeCard(card);
        if (!data) continue;
        // Indexa por anunciante e copy ANTES de decorar (pra ter contadores certos)
        if (data.advertiser) {
          if (!adsByAdvertiser.has(data.advertiser)) adsByAdvertiser.set(data.advertiser, new Set());
          adsByAdvertiser.get(data.advertiser).add(data.id);
        }
        if (data.copyFp) {
          if (!adsByCopyFp.has(data.copyFp)) adsByCopyFp.set(data.copyFp, new Set());
          adsByCopyFp.get(data.copyFp).add(data.id);
        }
        decorateCard(card, data);
        detectedAds.set(data.id, data);
        cardById.set(data.id, card);
        if (data.ticketClass === "low") newLow++;
        else if (data.ticketClass === "mid") newMid++;
        else if (data.ticketClass === "high") newHigh++;
      } catch (e) {
        failed++;
        ERR("analyzeCard/decorateCard falhou:", e);
      }
    }
    // Após indexar todos, re-renderiza badges de variação (que dependem dos contadores finais)
    try { refreshVariationBadges(); } catch (e) { ERR("refreshVariationBadges:", e); }
    if (failed > 0) WARN(`${failed} card(s) com erro`);
    try { applyFilter(); } catch (e) { ERR("applyFilter:", e); }
    try { updateHud(); } catch (e) { ERR("updateHud:", e); }
    if (newLow + newMid + newHigh > 0) {
      try {
        chrome.runtime.sendMessage({ type: "STATS_UPDATE", stats: getStats() });
      } catch (e) {}
    }
  }

  function getStats() {
    let low = 0, mid = 0, high = 0, withDate = 0, withVideo = 0, withLp = 0;
    let withGuarantee = 0, hot = 0; // hot = score >= 55
    const niches = {};
    const types = { ecommerce: 0, digital: 0, dorama: 0, servico: 0, outro: 0 };
    const platforms = {};
    for (const ad of detectedAds.values()) {
      if (ad.ticketClass === "low") low++;
      else if (ad.ticketClass === "mid") mid++;
      else if (ad.ticketClass === "high") high++;
      if (ad.daysRunning != null) withDate++;
      if (ad.hasVideo) withVideo++;
      if (ad.landingPage) withLp++;
      if (ad.guaranteeDays && ad.guaranteeDays > 0) withGuarantee++;
      if ((ad.viralScore || 0) >= 55) hot++;
      niches[ad.niche] = (niches[ad.niche] || 0) + 1;
      if (types[ad.offerType] != null) types[ad.offerType]++;
      else types.outro++;
      if (ad.platform) platforms[ad.platform] = (platforms[ad.platform] || 0) + 1;
    }
    return {
      total: detectedAds.size,
      low, mid, high, niches, types, platforms,
      withDate, withVideo, withLp, withGuarantee, hot,
      scans: scanCount,
      minDaysFilter, typeFilter, onlyLowTicket, minViralScore, autoScrollActive
    };
  }

  // ---------- HUD ----------
  let hudEl = null;
  function ensureHud() {
    if (hudEl) return hudEl;
    hudEl = document.createElement("div");
    hudEl.id = "lth-hud";
    hudEl.innerHTML = `
      <div class="lth-hud-header">
        <span class="lth-hud-title">🎯 Hunter X</span>
        <button class="lth-hud-toggle" title="Minimizar">_</button>
      </div>
      <div class="lth-hud-body">
        <div class="lth-hud-stats">
          <div class="lth-stat"><b id="lth-c-low">0</b><span>🎯 Low</span></div>
          <div class="lth-stat"><b id="lth-c-mid">0</b><span>⚡ Mid</span></div>
          <div class="lth-stat"><b id="lth-c-high">0</b><span>💎 High</span></div>
          <div class="lth-stat"><b id="lth-c-hot">0</b><span>🔥 Hot</span></div>
        </div>

        <div id="lth-adv-filter-bar" class="lth-adv-bar" style="display:none">
          <span>🔁 Filtrando: <b id="lth-adv-filter-name">—</b></span>
          <button id="lth-adv-clear" title="Remover filtro">✕</button>
        </div>

        <div class="lth-section-title">🔥 Top anunciantes (variações)</div>
        <ul id="lth-top-adv" class="lth-top-list"><li class="lth-empty">Nada ainda</li></ul>

        <div class="lth-section-title">Mostrar tipos</div>
        <div class="lth-toggles">
          <label class="lth-tg"><input type="checkbox" id="lth-tg-ecom" checked /><span>🛒 E-com <i id="lth-c-ecom">0</i></span></label>
          <label class="lth-tg"><input type="checkbox" id="lth-tg-digital" checked /><span>💻 Digital <i id="lth-c-digital">0</i></span></label>
          <label class="lth-tg"><input type="checkbox" id="lth-tg-outro" checked /><span>❓ Outro <i id="lth-c-outro">0</i></span></label>
          <label class="lth-tg lth-tg-off"><input type="checkbox" id="lth-tg-serv" /><span>🛠 Serviço <i id="lth-c-serv">0</i></span></label>
          <label class="lth-tg lth-tg-off"><input type="checkbox" id="lth-tg-dor" /><span>🎭 Dorama <i id="lth-c-dor">0</i></span></label>
        </div>

        <div class="lth-section-title">Filtros</div>
        <label class="lth-tg lth-tg-bold">
          <input type="checkbox" id="lth-tg-onlylow" />
          <span>🎯 Só Low Ticket</span>
        </label>

        <div class="lth-filter">
          <label>≥ <span id="lth-min-days-val">0</span> dias rodando</label>
          <input type="range" id="lth-min-days" min="0" max="60" step="1" value="0" />
        </div>

        <div class="lth-filter">
          <label>Score viral ≥ <span id="lth-min-score-val">0</span></label>
          <input type="range" id="lth-min-score" min="0" max="100" step="5" value="0" />
        </div>

        <div class="lth-section-title">Automação</div>
        <label class="lth-tg lth-tg-fire">
          <input type="checkbox" id="lth-tg-autoscroll" />
          <span>🔁 Auto-scroll <i class="lth-kbd">A</i></span>
        </label>

        <div class="lth-hud-row"><span>🎥 Com vídeo</span><b id="lth-c-vid">0</b></div>
        <div class="lth-hud-row"><span>🔗 Com LP</span><b id="lth-c-lp">0</b></div>
        <div class="lth-hud-row"><span>🛡 Com garantia</span><b id="lth-c-guar">0</b></div>
        <div class="lth-hud-row"><span>Total</span><b id="lth-c-total">0</b></div>

        <div class="lth-hud-actions">
          <button id="lth-scan-now" title="Atalho: S">🔄 Escanear</button>
          <button id="lth-export">📥 CSV</button>
          <button id="lth-export-json">{ } JSON</button>
        </div>

        <div class="lth-shortcuts">
          <i class="lth-kbd">L</i> só low · <i class="lth-kbd">S</i> escanear · <i class="lth-kbd">A</i> auto-scroll
        </div>
      </div>
    `;
    document.body.appendChild(hudEl);
    const safeOn = (sel, ev, fn) => {
      const el = hudEl.querySelector(sel);
      if (el) el.addEventListener(ev, fn);
      else WARN("HUD: elemento não encontrado", sel);
    };
    safeOn(".lth-hud-toggle", "click", () => hudEl.classList.toggle("lth-min"));
    safeOn("#lth-scan-now", "click", () => scan());
    safeOn("#lth-export", "click", () => exportCsv());
    safeOn("#lth-export-json", "click", () => exportJson());

    // Slider de dias
    const slider = hudEl.querySelector("#lth-min-days");
    const sliderVal = hudEl.querySelector("#lth-min-days-val");
    slider.value = minDaysFilter;
    sliderVal.textContent = minDaysFilter;
    slider.addEventListener("input", (e) => {
      minDaysFilter = parseInt(e.target.value, 10) || 0;
      sliderVal.textContent = minDaysFilter;
      applyFilter();
      try { chrome.storage.local.set({ minDaysFilter }); } catch (e) {}
    });

    // Slider de score
    const scoreSlider = hudEl.querySelector("#lth-min-score");
    const scoreVal = hudEl.querySelector("#lth-min-score-val");
    scoreSlider.value = minViralScore;
    scoreVal.textContent = minViralScore;
    scoreSlider.addEventListener("input", (e) => setMinScore(e.target.value));

    // Toggles de tipo
    const tgMap = {
      "lth-tg-ecom": "ecommerce",
      "lth-tg-digital": "digital",
      "lth-tg-outro": "outro",
      "lth-tg-serv": "servico",
      "lth-tg-dor": "dorama"
    };
    for (const [id, key] of Object.entries(tgMap)) {
      const el = hudEl.querySelector("#" + id);
      if (!el) continue;
      el.checked = !!typeFilter[key];
      el.addEventListener("change", (e) => setTypeFilter(key, e.target.checked));
    }

    // Só low
    const ol = hudEl.querySelector("#lth-tg-onlylow");
    ol.checked = onlyLowTicket;
    ol.addEventListener("change", (e) => setOnlyLow(e.target.checked));

    // Auto-scroll
    const as = hudEl.querySelector("#lth-tg-autoscroll");
    as.checked = autoScrollActive;
    as.addEventListener("change", (e) => {
      if (e.target.checked) startAutoScroll();
      else stopAutoScroll();
    });

    // Botão limpar filtro de anunciante
    const clr = hudEl.querySelector("#lth-adv-clear");
    if (clr) clr.addEventListener("click", () => {
      advertiserFilter = null;
      applyFilter();
      showToast("✋ Filtro de anunciante removido");
    });

    return hudEl;
  }

  function updateHud() {
    ensureHud();
    const s = getStats();
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set("lth-c-low", s.low);
    set("lth-c-mid", s.mid);
    set("lth-c-high", s.high);
    set("lth-c-hot", s.hot);
    set("lth-c-total", s.total);
    set("lth-c-ecom", s.types.ecommerce);
    set("lth-c-digital", s.types.digital);
    set("lth-c-outro", s.types.outro);
    set("lth-c-serv", s.types.servico);
    set("lth-c-dor", s.types.dorama);
    set("lth-c-guar", s.withGuarantee);

    // Renderiza top 5 anunciantes com mais variações
    const topUl = document.getElementById("lth-top-adv");
    if (topUl) {
      const entries = Array.from(adsByAdvertiser.entries())
        .map(([adv, set]) => [adv, set.size])
        .filter(([_, c]) => c >= 1)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
      if (entries.length === 0) {
        topUl.innerHTML = '<li class="lth-empty">Nada ainda</li>';
      } else {
        topUl.innerHTML = "";
        for (const [adv, count] of entries) {
          const li = document.createElement("li");
          li.className = "lth-top-item";
          if (advertiserFilter === adv) li.classList.add("lth-top-active");
          const advShort = adv.length > 22 ? adv.slice(0, 21) + "…" : adv;
          li.innerHTML = `<span title="${adv.replace(/"/g,"&quot;")}">${advShort}</span><b>${count}</b>`;
          li.style.cursor = "pointer";
          li.title = `Clique para ver só "${adv}"`;
          li.addEventListener("click", () => {
            if (advertiserFilter === adv) {
              advertiserFilter = null;
              showToast("✋ Filtro removido");
            } else {
              advertiserFilter = adv;
              showToast(`🔁 Só "${adv}"`);
            }
            applyFilter();
            updateHud();
          });
          topUl.appendChild(li);
        }
      }
    }
    set("lth-c-vid", s.withVideo);
    set("lth-c-lp", s.withLp);
    set("lth-c-date", s.withDate);
  }

  // ---------- CSV ----------
  function exportCsv() {
    const rows = [[
      "anunciante","preco","ticket","tipo_oferta","plataforma","score_viral",
      "nicho","gatilhos","garantia_dias",
      "dias_rodando","data_inicio","tem_video","tem_lp","landing_page",
      "trecho","capturado_em"
    ]];
    for (const ad of detectedAds.values()) {
      if (typeFilter[ad.offerType] === false) continue; // pula tipos desativados
      rows.push([
        ad.advertiser || "",
        ad.price != null ? ad.price.toFixed(2) : "",
        ad.ticketClass || "",
        ad.offerType || "",
        ad.platform || "",
        ad.viralScore != null ? ad.viralScore : "",
        ad.niche || "",
        (ad.triggers || []).join("|"),
        ad.guaranteeDays != null ? ad.guaranteeDays : "",
        ad.daysRunning != null ? ad.daysRunning : "",
        ad.startDate ? ad.startDate.slice(0, 10) : "",
        ad.hasVideo ? "sim" : "não",
        ad.landingPage ? "sim" : "não",
        ad.landingPage || "",
        (ad.snippet || "").replace(/"/g, "'"),
        ad.capturedAt || ""
      ]);
    }
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `low-ticket-meta_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
  }

  // ---------- EXPORT JSON ----------
  function exportJson() {
    const ads = Array.from(detectedAds.values()).filter(ad => typeFilter[ad.offerType] !== false);
    const payload = {
      generatedAt: new Date().toISOString(),
      total: ads.length,
      stats: getStats(),
      ads: ads
    };
    const json = JSON.stringify(payload, null, 2);
    const blob = new Blob([json], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `low-ticket-meta_${new Date().toISOString().slice(0,10)}.json`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
    showToast("📥 JSON exportado!");
  }

  // ---------- ATALHOS DE TECLADO ----------
  function setupShortcuts() {
    document.addEventListener("keydown", (e) => {
      // Ignora se estiver digitando em input/textarea/contenteditable
      const t = e.target;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
      if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;

      const k = e.key.toLowerCase();
      if (k === "l") {
        e.preventDefault();
        setOnlyLow(!onlyLowTicket);
        const cb = document.getElementById("lth-tg-onlylow");
        if (cb) cb.checked = onlyLowTicket;
        showToast(onlyLowTicket ? "🎯 Só low ticket ON" : "🎯 Só low ticket OFF");
      } else if (k === "s") {
        e.preventDefault();
        scan();
        showToast("🔄 Escaneado");
      } else if (k === "a") {
        e.preventDefault();
        toggleAutoScroll();
        const cb = document.getElementById("lth-tg-autoscroll");
        if (cb) cb.checked = autoScrollActive;
        showToast(autoScrollActive ? "🔁 Auto-scroll ON" : "✋ Auto-scroll OFF");
      }
    });
  }

  // ---------- BOOT ----------
  function boot() {
    LOG("boot iniciando, URL:", location.href);
    try {
      ensureHud();
      LOG("HUD criado");
    } catch (e) {
      ERR("ensureHud falhou:", e);
    }
    try { syncToggleUI(); } catch (e) { ERR("syncToggleUI:", e); }
    try { setupShortcuts(); LOG("atalhos prontos"); } catch (e) { ERR("setupShortcuts:", e); }
    try { scan(); } catch (e) { ERR("scan inicial:", e); }

    try {
      const obs = new MutationObserver(() => {
        if (boot._t) clearTimeout(boot._t);
        boot._t = setTimeout(() => {
          try { scan(); } catch (e) { ERR("scan (observer):", e); }
        }, 600);
      });
      obs.observe(document.body, { childList: true, subtree: true });
      LOG("observer ativado");
    } catch (e) {
      ERR("MutationObserver:", e);
    }

    let scrollT = null;
    window.addEventListener("scroll", () => {
      if (scrollT) clearTimeout(scrollT);
      scrollT = setTimeout(() => {
        try { scan(); } catch (e) { ERR("scan (scroll):", e); }
      }, 800);
    }, { passive: true });

    LOG("boot completo ✓");
  }

  // Mensagens do popup
  chrome.runtime.onMessage.addListener((msg, sender, send) => {
    if (msg && msg.type === "GET_STATS") {
      send({ ok: true, stats: getStats(), ads: Array.from(detectedAds.values()) });
      return true;
    }
    if (msg && msg.type === "RESCAN") {
      scan(); send({ ok: true }); return true;
    }
    if (msg && msg.type === "EXPORT_CSV") {
      exportCsv(); send({ ok: true }); return true;
    }
    if (msg && msg.type === "EXPORT_JSON") {
      exportJson(); send({ ok: true }); return true;
    }
    if (msg && msg.type === "SET_MIN_DAYS") {
      minDaysFilter = parseInt(msg.value, 10) || 0;
      const s = document.getElementById("lth-min-days");
      const v = document.getElementById("lth-min-days-val");
      if (s) s.value = minDaysFilter;
      if (v) v.textContent = minDaysFilter;
      applyFilter();
      try { chrome.storage.local.set({ minDaysFilter }); } catch(e) {}
      send({ ok: true });
      return true;
    }
    if (msg && msg.type === "SET_TYPE_FILTER") {
      if (msg.filter && typeof msg.filter === "object") {
        typeFilter = Object.assign(typeFilter, msg.filter);
        try { chrome.storage.local.set({ typeFilter }); } catch (e) {}
        applyFilter();
        syncToggleUI();
        updateHud();
      }
      send({ ok: true });
      return true;
    }
    if (msg && msg.type === "SET_ONLY_LOW") {
      setOnlyLow(!!msg.value);
      syncToggleUI();
      send({ ok: true });
      return true;
    }
    if (msg && msg.type === "SET_MIN_SCORE") {
      setMinScore(msg.value);
      send({ ok: true });
      return true;
    }
    if (msg && msg.type === "TOGGLE_AUTOSCROLL") {
      toggleAutoScroll();
      send({ ok: true, active: autoScrollActive });
      return true;
    }
  });

  // ── Verificação de licença antes de iniciar ──────────────────────────────
  function isLicenseValid(keyStr) {
    if (!keyStr || !keyStr.startsWith("HX-")) return false;
    try {
      const inner = keyStr.trim().slice(3);
      const dot = inner.lastIndexOf(".");
      if (dot === -1) return false;
      const payloadB64 = inner.slice(0, dot);
      // base64url → base64 padrão
      const padded = payloadB64.replace(/-/g, '+').replace(/_/g, '/');
      const padding = '='.repeat((4 - padded.length % 4) % 4);
      const payload = JSON.parse(atob(padded + padding));
      if (!payload.ex) return false;
      return new Date(payload.ex) > new Date();
    } catch (_) { return false; }
  }

  chrome.storage.local.get(["licenseKey"], ({ licenseKey }) => {
    if (!isLicenseValid(licenseKey)) {
      LOG("Licença não encontrada ou expirada — painel não iniciado.");
      return; // não injeta o HUD
    }
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot);
    } else {
      boot();
    }
  });
})();
