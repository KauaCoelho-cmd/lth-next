# 🎯 Low Ticket Hunter — Meta Ad Library

Extensão Chrome que detecta automaticamente anúncios de produtos **low ticket** (até R$ 100) na Biblioteca de Anúncios do Meta.

## O que ela faz

- 🔍 **Escaneia automaticamente** todos os anúncios visíveis na Biblioteca de Anúncios (`facebook.com/ads/library`)
- 🎯 **Destaca com borda verde** os anúncios low ticket (R$ ≤ 100)
- ⚡ **Marca em laranja** os mid ticket (R$ 100,01 a R$ 500)
- 💎 **Marca em cinza** os high ticket (acima de R$ 500)
- 📅 **Detecta há quantos dias o anúncio está rodando** — quanto mais tempo, mais validado (badge 🔥 a partir de 7 dias, 🔥🔥 a partir de 30)
- 🎚️ **Filtro "tempo mínimo rodando"** — slider que esconde anúncios com menos de X dias (ótimo pra achar só os escalando)
- 🎯 **Classifica por tipo de oferta**: 🛒 e-commerce, 💻 produto digital, 🎭 dorama/streaming, 🛠 serviço, ❓ outro
- 🚫 **Filtra automaticamente doramas e serviços** (vêm desligados por padrão) — você só vê o que importa
- 🔗 **Botão "Ir para LP"** — abre a landing page do anúncio em nova aba
- 📥 **Botão "Baixar vídeo"** — salva o vídeo do criativo direto no seu PC
- 🏷️ **Classifica por nicho**: Renda Extra, Saúde/Fitness, Relacionamento, Espiritualidade, Geral
- 🔥 **Detecta gatilhos** de info-produto (ebook, método, vitalício, etc.)
- ⭐ **Salva favoritos** com 1 clique
- 📊 **Exporta CSV** com tudo que foi capturado (incluindo dias rodando e URL da LP)
- 📍 **HUD flutuante** com contadores em tempo real

## Como instalar

### 1. Abra o Chrome em modo desenvolvedor

1. Abra o Google Chrome
2. Cole na barra de endereço: `chrome://extensions/`
3. No canto superior direito, ative o switch **"Modo do desenvolvedor"**

### 2. Carregue a extensão

1. Clique no botão **"Carregar sem compactação"** (Load unpacked)
2. Selecione a pasta `low-ticket-meta-extension` (esta pasta aqui)
3. Pronto! Você verá o ícone 🎯 verde na barra do Chrome

### 3. Use

1. Vá para a Biblioteca de Anúncios do Meta:
   - 🇧🇷 Brasil: <https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=BR>
2. Pesquise por palavras-chave (ex: "emagrecer", "renda extra", "ebook")
3. A extensão automaticamente:
   - Destaca os anúncios com borda colorida
   - Mostra um painel HUD no canto inferior direito com os contadores
   - Adiciona o badge do preço detectado em cada anúncio
4. Clique no ícone 🎯 da extensão para abrir o popup com estatísticas, favoritos e exportar CSV
5. Clique em **⭐ Salvar** em qualquer anúncio para guardá-lo nos favoritos

## Como funciona a detecção

A extensão lê o texto visível de cada card de anúncio e procura por padrões de preço em PT-BR:

- `R$ 27` / `R$ 27,90` / `R$ 1.997,00`
- `27 reais` / `97 reais`

E classifica:

| Faixa | Categoria | Visual |
|---|---|---|
| R$ 1 a R$ 100 | 🎯 LOW TICKET | Borda verde |
| R$ 100,01 a R$ 500 | ⚡ MID TICKET | Borda laranja tracejada |
| > R$ 500 | 💎 HIGH TICKET | Borda cinza tracejada |

Também classifica por **nicho** com base em palavras-chave:

- 💰 **Renda Extra**: renda extra, ganhar dinheiro, hotmart, afiliados, dropship, gringa, etc.
- 🏃 **Saúde/Fitness**: emagrecer, perder peso, dieta, treino, fitness, etc.
- 💕 **Relacionamento**: reconquista, ex namorado, autoestima, sedução, etc.
- 🔮 **Espiritualidade**: manifestação, lei da atração, tarot, anjos, etc.
- 📦 **Geral**: tudo que não cair nas outras categorias

E detecta **gatilhos de info-produto**: ebook, PDF, checklist, minicurso, método, vitalício, "por apenas", "última chance", "garanta já", etc.

## Estrutura dos arquivos

```
low-ticket-meta-extension/
├── manifest.json        # Configuração da extensão (Manifest V3)
├── content.js           # Scanner que roda na Biblioteca
├── content.css          # Estilos visuais (badges + HUD)
├── popup.html           # Interface da extensão
├── popup.css            # Estilos do popup
├── popup.js             # Lógica do popup
├── background.js        # Service worker (storage + badge)
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md            # Este arquivo
```

## Privacidade

- ✅ **100% local**: tudo roda no seu navegador, nada vai pra servidor externo
- ✅ **Sem login**: usa só a Biblioteca de Anúncios pública do Meta
- ✅ **Sem coleta de dados**: seus favoritos ficam salvos no `chrome.storage.local` (apenas no seu PC)

## Próximos passos / roadmap

- [ ] Filtro avançado: por preço mínimo/máximo, dias rodando, nicho
- [ ] Detecção via análise da landing page (abrir o link em iframe escondido)
- [ ] Score de "potencial viral" (anúncios rodando há +7 dias com múltiplas variações)
- [ ] Exportar para Notion/Google Sheets
- [ ] Modo "alerta": notificação quando achar um low ticket novo de um nicho específico
- [ ] Versão SaaS (backend + login + multi-usuário) — quando o MVP estiver validado

## Dúvidas / problemas

Se a extensão não estiver detectando anúncios:

1. Recarregue a página da Biblioteca (F5)
2. Espere alguns segundos enquanto os anúncios carregam
3. Clique em **🔄 Reescanear página** no popup ou no HUD
4. Role a página para baixo — a extensão escaneia conforme novos anúncios aparecem

---

## v1.3.0 — Arsenal completo de caçador

- 🔁 **Auto-scroll** com toggle (rola sozinho, pausa quando chega no fim)
- ⭐ **Score viral 0-100** em cada anúncio (combina dias rodando + gatilhos + vídeo + LP + garantia + preço)
- 🏪 **Detecção de plataforma**: Hotmart, Kiwify, Eduzz, Monetizze, PerfectPay, Cakto, Pepper, Shopee, Mercado Livre, Amazon, Shopify, Yampi, Nuvemshop, Ticto, Lastlink
- 🛡 **Detecta garantia** ("7 dias de garantia", "30 dias para testar", etc.)
- 🎯 **Filtro "Só Low Ticket"** com um clique
- 📋 **Botão copiar texto** do anúncio (clipboard)
- 📥 **Export JSON** além de CSV
- ⌨️ **Atalhos de teclado**: `L` só low · `S` escanear · `A` auto-scroll
- 🔥 **10 novas palavras-gatilho** modernas: PIX, vagas limitadas, garantia 7 dias, menos de R$1 por dia, antes que esgote, viralizou, descobri, em 7 dias, atenção, dinheiro de volta

---

**v1.3.0** · feito para localizar low ticket dentro do Meta 🎯
