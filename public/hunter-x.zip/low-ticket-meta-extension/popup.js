/* Hunter X — popup */

/* ============================================================
   LICENÇA — validação HMAC local (sem servidor)

   ⚠️  IMPORTANTE: troque HX_SECRET pelo mesmo valor
       que você colocar em HX_SECRET no Vercel.
       As chaves só validam se os segredos forem iguais.
   ============================================================ */
const HX_SECRET = "64956424f9bfa7577ffebb443a4ea8dfba954724b7f6b399d65084b9c7ea4c2c";

/*
  Formato da chave:
    HX-{base64(payload)}.{hmac_hex}

  Payload (JSON compacto):
    { e: "email@cliente.com", ex: "2026-06-22", id: "uuid" }

  Exemplo de chave gerada:
    HX-eyJlIjoidXNlckBlbWFpbC5jb20iLCJleCI6IjIwMjYtMDYtMjIiLCJpZCI6ImFiYzEyMyJ9.a3f9b2c1...
*/

/* ---------- crypto helpers ---------- */

// Decodifica base64url → string (compatível com o que o servidor gera)
function decodeB64url(b64url) {
  const padded = b64url.replace(/-/g, '+').replace(/_/g, '/');
  const padding = '='.repeat((4 - padded.length % 4) % 4);
  return atob(padded + padding);
}

/* ---------- valida chave localmente (offline, sem servidor) ---------- */

async function verifyLicenseKey(keyStr) {
  if (!keyStr || !keyStr.startsWith("HX-")) return null;

  const inner = keyStr.trim().slice(3);
  const dot = inner.lastIndexOf(".");
  if (dot === -1) return null;

  const payloadB64 = inner.slice(0, dot); // base64url
  const sigHex     = inner.slice(dot + 1); // primeiros 24 chars do hex

  try {
    // 1. Computa HMAC-SHA256 do payload e pega os primeiros 24 chars hex
    const enc = new TextEncoder();
    const cryptoKey = await crypto.subtle.importKey(
      "raw", enc.encode(HX_SECRET),
      { name: "HMAC", hash: "SHA-256" },
      false, ["sign"]
    );
    const sigBuf = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(payloadB64));
    const fullHex = Array.from(new Uint8Array(sigBuf))
      .map(b => b.toString(16).padStart(2, "0")).join("");
    const expectedSig = fullHex.slice(0, 24);

    if (expectedSig !== sigHex) return null;

    // 2. Decodifica payload base64url
    const payload = JSON.parse(decodeB64url(payloadB64));

    // 3. Verifica expiração
    if (!payload.ex || new Date(payload.ex) < new Date()) return null;

    return { email: payload.e, expiresAt: payload.ex, id: payload.id };
  } catch (_) {
    return null;
  }
}

/* ---------- checa licença no storage ---------- */

async function checkLicenseStatus() {
  const { licenseKey } = await chrome.storage.local.get(["licenseKey"]);
  if (!licenseKey) return { valid: false };

  const payload = await verifyLicenseKey(licenseKey);
  if (!payload) return { valid: false, reason: "invalid_or_expired" };

  return { valid: true, email: payload.email, expiresAt: payload.expiresAt };
}

/* ---------- ativa e persiste a chave ---------- */

async function activateLicense(key) {
  const clean = key.trim();
  if (!clean) throw new Error("Digite a chave de acesso");

  const payload = await verifyLicenseKey(clean);

  if (!payload) {
    // Distingue chave adulterada de chave expirada
    if (clean.startsWith("HX-")) {
      throw new Error("Chave expirada ou inválida. Renove seu plano.");
    }
    throw new Error("Formato de chave incorreto. Copie exatamente como recebeu.");
  }

  await chrome.storage.local.set({ licenseKey: clean });
  return payload;
}

/* ---------- show/hide ---------- */

function showGate() {
  document.getElementById("license-gate").classList.remove("hidden");
  document.getElementById("main-app").classList.add("hidden");
}

function showApp(email, expiresAt, offline) {
  document.getElementById("license-gate").classList.add("hidden");
  document.getElementById("main-app").classList.remove("hidden");

  // ── Timer de dias restantes ──────────────────────────────────
  const bar = document.getElementById("license-status-bar");
  if (bar && expiresAt) {
    const now   = new Date();
    const exp   = new Date(expiresAt);
    const diff  = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
    const expDate = exp.toLocaleDateString("pt-BR");

    let timerClass = "timer-ok";
    let icon = "🟢";
    if (diff <= 0) {
      timerClass = "timer-expired";
      icon = "🔴";
    } else if (diff <= 7) {
      timerClass = "timer-warning";
      icon = "🟡";
    }

    const daysText = diff <= 0
      ? "Expirado"
      : diff === 1
        ? "1 dia restante"
        : `${diff} dias restantes`;

    bar.innerHTML = `
      <div class="license-timer ${timerClass}">
        <div class="timer-left">
          <span class="timer-icon">${icon}</span>
          <div>
            <span class="timer-days">${daysText}</span>
            <span class="timer-email">${email || ""}</span>
          </div>
        </div>
        <div class="timer-exp">vence ${expDate}</div>
      </div>`;
    bar.classList.remove("hidden");
  }
}

/* ============================================================ */

const NICHE_LABEL = {
  "renda_extra": "💰 Renda Extra",
  "saude_emagrecimento": "🏃 Saúde / Fitness",
  "relacionamento": "💕 Relacionamento",
  "espiritualidade": "🔮 Espiritualidade",
  "geral": "📦 Geral"
};

const $ = (id) => document.getElementById(id);

function setStatus(text, kind) {
  $("status-text").textContent = text;
  const s = document.querySelector(".status");
  s.classList.remove("ok", "err");
  if (kind) s.classList.add(kind);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isLibraryUrl(url) {
  return url && /facebook\.com\/ads\/library/.test(url);
}

async function refreshStats() {
  const tab = await getActiveTab();
  if (!isLibraryUrl(tab?.url)) {
    setStatus("Abra a Biblioteca de Anúncios para escanear", "err");
    return;
  }
  setStatus("Conectado · escaneando", "ok");

  chrome.tabs.sendMessage(tab.id, { type: "GET_STATS" }, (resp) => {
    if (chrome.runtime.lastError || !resp || !resp.ok) {
      setStatus("Recarregue a página da Biblioteca", "err");
      return;
    }
    const s = resp.stats || {};
    $("s-low").textContent = s.low || 0;
    $("s-mid").textContent = s.mid || 0;
    $("s-high").textContent = s.high || 0;
    if ($("s-vid")) $("s-vid").textContent = s.withVideo || 0;
    if ($("s-lp"))  $("s-lp").textContent = s.withLp || 0;
    if ($("s-date")) $("s-date").textContent = s.withDate || 0;

    // contadores por tipo
    const t = s.types || {};
    if ($("t-ecom")) $("t-ecom").textContent = t.ecommerce || 0;
    if ($("t-digital")) $("t-digital").textContent = t.digital || 0;
    if ($("t-outro")) $("t-outro").textContent = t.outro || 0;
    if ($("t-serv")) $("t-serv").textContent = t.servico || 0;
    if ($("t-dor")) $("t-dor").textContent = t.dorama || 0;

    // sincroniza toggles com filtro do content
    const tf = s.typeFilter || {};
    if ($("tg-ecommerce")) $("tg-ecommerce").checked = tf.ecommerce !== false;
    if ($("tg-digital"))  $("tg-digital").checked  = tf.digital !== false;
    if ($("tg-outro"))    $("tg-outro").checked    = tf.outro !== false;
    if ($("tg-servico"))  $("tg-servico").checked  = !!tf.servico;
    if ($("tg-dorama"))   $("tg-dorama").checked   = !!tf.dorama;

    // sincroniza slider com filtro atual
    if ($("min-days") && s.minDaysFilter != null) {
      $("min-days").value = s.minDaysFilter;
      $("min-days-val").textContent = s.minDaysFilter;
    }

    const list = $("niche-list");
    list.innerHTML = "";
    const entries = Object.entries(s.niches || {}).sort((a, b) => b[1] - a[1]);
    if (entries.length === 0) {
      list.innerHTML = '<li class="empty">Sem dados ainda</li>';
    } else {
      for (const [n, c] of entries) {
        const li = document.createElement("li");
        li.innerHTML = `<span>${NICHE_LABEL[n] || n}</span><b>${c}</b>`;
        list.appendChild(li);
      }
    }
  });
}

async function setMinDays(value) {
  await chrome.storage.local.set({ minDaysFilter: value });
  const tab = await getActiveTab();
  if (isLibraryUrl(tab?.url)) {
    chrome.tabs.sendMessage(tab.id, { type: "SET_MIN_DAYS", value });
  }
}

const TYPE_KEYS = {
  "tg-ecommerce": "ecommerce",
  "tg-digital": "digital",
  "tg-outro": "outro",
  "tg-servico": "servico",
  "tg-dorama": "dorama"
};

async function setTypeFilter(key, value) {
  const cur = (await chrome.storage.local.get(["typeFilter"])).typeFilter || {};
  cur[key] = !!value;
  await chrome.storage.local.set({ typeFilter: cur });
  const tab = await getActiveTab();
  if (isLibraryUrl(tab?.url)) {
    chrome.tabs.sendMessage(tab.id, { type: "SET_TYPE_FILTER", filter: { [key]: !!value } });
  }
}

async function rescan() {
  const tab = await getActiveTab();
  if (!isLibraryUrl(tab?.url)) {
    setStatus("Abra a Biblioteca de Anúncios primeiro", "err");
    return;
  }
  chrome.tabs.sendMessage(tab.id, { type: "RESCAN" }, () => {
    setTimeout(refreshStats, 500);
  });
}

async function exportCsv() {
  const tab = await getActiveTab();
  if (!isLibraryUrl(tab?.url)) {
    setStatus("Abra a Biblioteca de Anúncios primeiro", "err");
    return;
  }
  chrome.tabs.sendMessage(tab.id, { type: "EXPORT_CSV" });
}

async function loadSaved() {
  const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
  $("saved-count").textContent = savedAds.length;
  const ul = $("saved-list");
  ul.innerHTML = "";
  if (savedAds.length === 0) {
    ul.innerHTML = '<li class="empty" style="text-align:center;color:#9ca3af;font-style:italic;padding:12px;">Nenhum anúncio salvo ainda</li>';
    return;
  }
  for (const ad of savedAds.slice().reverse()) {
    const li = document.createElement("li");
    const price = ad.priceRaw || (ad.price != null ? `R$ ${ad.price.toFixed(2)}` : "—");
    const daysHtml = ad.daysRunning != null
      ? `<span class="ad-days ${ad.daysRunning >= 30 ? 'fire' : ad.daysRunning >= 7 ? 'hot' : ''}">🔥 ${ad.daysRunning}d</span>`
      : "";
    const lpHtml = ad.landingPage
      ? `<a href="${escapeHtml(ad.landingPage)}" target="_blank" rel="noopener" class="ad-lp">🔗 LP</a>`
      : "";
    const vidHtml = ad.hasVideo ? `<span class="ad-vid">🎥</span>` : "";

    li.innerHTML = `
      <div class="ad-head">
        <span class="ad-adv">${escapeHtml(ad.advertiser || "Anunciante")}</span>
        <span class="ad-price">${escapeHtml(price)}</span>
      </div>
      <div class="ad-snip">${escapeHtml((ad.snippet || "").slice(0, 140))}…</div>
      <div class="ad-meta">
        <span>${NICHE_LABEL[ad.niche] || "📦"}</span>
        ${daysHtml}
        ${vidHtml}
        ${lpHtml}
        <span class="ad-date">${new Date(ad.capturedAt).toLocaleDateString("pt-BR")}</span>
      </div>
    `;
    ul.appendChild(li);
  }
}

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

async function exportSaved() {
  const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
  if (savedAds.length === 0) return;

  const rows = [[
    "anunciante","preco","ticket","nicho","gatilhos",
    "dias_rodando","data_inicio","tem_video","landing_page",
    "trecho","capturado_em"
  ]];
  for (const ad of savedAds) {
    rows.push([
      ad.advertiser || "",
      ad.price != null ? ad.price.toFixed(2) : "",
      ad.ticketClass || "",
      ad.niche || "",
      (ad.triggers || []).join("|"),
      ad.daysRunning != null ? ad.daysRunning : "",
      ad.startDate ? ad.startDate.slice(0, 10) : "",
      ad.hasVideo ? "sim" : "não",
      ad.landingPage || "",
      (ad.snippet || "").replace(/"/g, "'"),
      ad.capturedAt || ""
    ]);
  }
  const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  await chrome.downloads.download({
    url,
    filename: `low-ticket-favoritos_${new Date().toISOString().slice(0,10)}.csv`,
    saveAs: true
  }).catch(() => {
    // fallback se chrome.downloads não estiver disponível
    const a = document.createElement("a");
    a.href = url;
    a.download = `low-ticket-favoritos_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
  });
}

async function clearSaved() {
  if (!confirm("Limpar todos os favoritos?")) return;
  await chrome.storage.local.set({ savedAds: [] });
  loadSaved();
}

document.addEventListener("DOMContentLoaded", async () => {
  /* ---- verifica licença primeiro ---- */
  const license = await checkLicenseStatus();

  if (!license.valid) {
    showGate();

    // Botão ativar
    document.getElementById("btn-activate").addEventListener("click", async () => {
      const key = document.getElementById("license-input").value;
      const btn = document.getElementById("btn-activate");
      const msg = document.getElementById("gate-msg");

      btn.disabled = true;
      btn.textContent = "Verificando...";
      msg.className = "gate-msg hidden";

      try {
        const result = await activateLicense(key);
        msg.textContent = `✅ Ativado com sucesso! Bem-vindo(a)!`;
        msg.className = "gate-msg ok";
        msg.classList.remove("hidden");

        setTimeout(async () => {
          // Recarrega a aba para o painel lateral aparecer sem precisar de F5
          const tab = await getActiveTab();
          if (tab && tab.id) {
            chrome.tabs.reload(tab.id, {}, () => {
              // Fecha o popup — vai reabrir automaticamente após o reload
              window.close();
            });
          } else {
            showApp(result.email, result.expiresAt, false);
            refreshStats();
            loadSaved();
            initFilters();
          }
        }, 1000);
      } catch (err) {
        msg.textContent = `❌ ${err.message}`;
        msg.className = "gate-msg err";
        msg.classList.remove("hidden");
        btn.disabled = false;
        btn.textContent = "Ativar agora";
      }
    });

    // Enter no input também ativa
    document.getElementById("license-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") document.getElementById("btn-activate").click();
    });

    return; // não inicializa o app ainda
  }

  /* ---- licença OK — inicia o app normalmente ---- */
  showApp(license.email, license.expiresAt, license.offline);
  refreshStats();
  loadSaved();
  initFilters();
  checkUpdateBanner();

  // Botão de logout
  document.getElementById("btn-logout").addEventListener("click", async () => {
    if (!confirm("Remover chave de licença? Você precisará ativar novamente.")) return;
    await chrome.storage.local.remove(["licenseKey"]);
    const tab = await getActiveTab();
    if (tab && tab.id) chrome.tabs.reload(tab.id);
    window.close();
  });
});

// ─── Banner de atualização ───────────────────────────────────────────────────
async function checkUpdateBanner() {
  try {
    const { updateAvailable } = await chrome.storage.local.get('updateAvailable');
    if (!updateAvailable) return;

    const banner = document.getElementById('update-banner');
    const msg = document.getElementById('update-msg');
    if (!banner) return;

    msg.textContent = `🚀 Hunter X ${updateAvailable.version} disponível!`;
    banner.classList.remove('hidden');

    banner.addEventListener('click', () => {
      chrome.tabs.create({ url: updateAvailable.url || 'https://hunterx.site/download' });
    });
  } catch (_) {}
}

async function initFilters() {

  // carrega filtro de dias salvo
  const { minDaysFilter = 0, typeFilter = {} } = await chrome.storage.local.get(["minDaysFilter", "typeFilter"]);
  if ($("min-days")) {
    $("min-days").value = minDaysFilter;
    $("min-days-val").textContent = minDaysFilter;
    $("min-days").addEventListener("input", (e) => {
      const v = parseInt(e.target.value, 10) || 0;
      $("min-days-val").textContent = v;
      setMinDays(v);
    });
  }

  // carrega + liga toggles de tipo
  const defaults = { ecommerce: true, digital: true, outro: true, servico: false, dorama: false };
  const tf = Object.assign({}, defaults, typeFilter);
  for (const [id, key] of Object.entries(TYPE_KEYS)) {
    const el = document.getElementById(id);
    if (!el) continue;
    el.checked = !!tf[key];
    el.addEventListener("change", (e) => setTypeFilter(key, e.target.checked));
  }

  $("btn-rescan").addEventListener("click", rescan);
  $("btn-export").addEventListener("click", exportCsv);
  $("btn-saved").addEventListener("click", () => {
    $("saved-section").classList.toggle("hidden");
  });
  $("btn-export-saved").addEventListener("click", exportSaved);
  $("btn-clear-saved").addEventListener("click", clearSaved);
  $("btn-open-library").addEventListener("click", () => {
    chrome.tabs.create({
      url: "https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=BR"
    });
  });

  $("btn-sitescope").addEventListener("click", async () => {
    const { licenseKey } = await chrome.storage.local.get(["licenseKey"]);
    if (!licenseKey) return;

    // Gera token temporário: HMAC do licenseKey + timestamp (validade 5min)
    const ts = Math.floor(Date.now() / 1000);
    const msg = `${licenseKey}:${ts}`;
    const enc = new TextEncoder();
    const cryptoKey = await crypto.subtle.importKey(
      "raw", enc.encode(HX_SECRET),
      { name: "HMAC", hash: "SHA-256" },
      false, ["sign"]
    );
    const sigBuf = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(msg));
    const sig = Array.from(new Uint8Array(sigBuf))
      .map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 32);

    const token = btoa(`${ts}:${sig}`).replace(/=/g, "");
    const key64 = btoa(licenseKey).replace(/=/g, "");

    chrome.tabs.create({
      url: `https://hunterx.site/sitescope?k=${encodeURIComponent(key64)}&t=${encodeURIComponent(token)}`
    });
  });
}
