/* Hunter X — popup */

/* ============================================================
   LICENÇA — validação HMAC local (sem servidor)

   ⚠️  IMPORTANTE: troque HX_SECRET pelo mesmo valor
       que você colocar em HX_SECRET no Vercel.
       As chaves só validam se os segredos forem iguais.
   ============================================================ */
const HX_SECRET = "64956424f9bfa7577ffebb443a4ea8dfba954724b7f6b399d65084b9c7ea4c2c";

/*
  Formato da chave:
    HX-{base64(payload)}.{hmac_hex}

  Payload (JSON compacto):
    { e: "email@cliente.com", ex: "2026-06-22", id: "uuid" }

  Exemplo de chave gerada:
    HX-eyJlIjoidXNlckBlbWFpbC5jb20iLCJleCI6IjIwMjYtMDYtMjIiLCJpZCI6ImFiYzEyMyJ9.a3f9b2c1...
*/

/* ---------- crypto helpers ---------- */

async function getHmacKey() {
  const enc = new TextEncoder();
  return crypto.subtle.importKey(
    "raw",
    enc.encode(HX_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"]
  );
}

function hexToBytes(hex) {
  const arr = new Uint8Array(hex.length / 2);
  for (let i = 0; i < arr.length; i++) {
    arr[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return arr;
}

/* ---------- valida chave localmente (offline, sem servidor) ---------- */

async function verifyLicenseKey(keyStr) {
  if (!keyStr || !keyStr.startsWith("HX-")) return null;

  const inner = keyStr.trim().slice(3);
  const dot = inner.lastIndexOf(".");
  if (dot === -1) return null;

  const payloadB64 = inner.slice(0, dot);
  const sigHex     = inner.slice(dot + 1);

  try {
    // 1. Verifica assinatura HMAC-SHA256
    const cryptoKey = await getHmacKey();
    const valid = await crypto.subtle.verify(
      "HMAC",
      cryptoKey,
      hexToBytes(sigHex),
      new TextEncoder().encode(payloadB64)
    );
    if (!valid) return null;

    // 2. Decodifica payload
    const payload = JSON.parse(atob(payloadB64));

    // 3. Verifica expiração
    if (!payload.ex || new Date(payload.ex) < new Date()) return null;

    return { email: payload.e, expiresAt: payload.ex, id: payload.id };
  } catch (_) {
    return null;
  }
}

/* ---------- checa licença no storage ---------- */

async function checkLicenseStatus() {
  const { licenseKey } = await chrome.storage.local.get(["licenseKey"]);
  if (!licenseKey) return { valid: false };

  const payload = await verifyLicenseKey(licenseKey);
  if (!payload) return { valid: false, reason: "invalid_or_expired" };

  return { valid: true, email: payload.email, expiresAt: payload.expiresAt };
}

/* ---------- ativa e persiste a chave ---------- */

async function activateLicense(key) {
  const clean = key.trim();
  if (!clean) throw new Error("Digite a chave de acesso");

  const payload = await verifyLicenseKey(clean);

  if (!payload) {
    // Distingue chave adulterada de chave expirada
    if (clean.startsWith("HX-")) {
      throw new Error("Chave expirada ou inválida. Renove seu plano.");
    }
    throw new Error("Formato de chave incorreto. Copie exatamente como recebeu.");
  }

  await chrome.storage.local.set({ licenseKey: clean });
  return payload;
}

/* ---------- show/hide ---------- */

function showGate() {
  document.getElementById("license-gate").classList.remove("hidden");
  document.getElementById("main-app").classList.add("hidden");
}

function showApp(email, expiresAt, offline) {
  document.getElementById("license-gate").classList.add("hidden");
  document.getElementById("main-app").classList.remove("hidden");

  const bar = document.getElementById("license-status-bar");
  if (bar) {
    const expDate = new Date(expiresAt).toLocaleDateString("pt-BR");
    const offlineTxt = offline ? " · (modo offline)" : "";
    bar.textContent = `✅ Ativo · ${email || ""}  · vence ${expDate}${offlineTxt}`;
    bar.classList.remove("hidden");
  }
}

/* ============================================================ */

const NICHE_LABEL = {
  "renda_extra": "💰 Renda Extra",
  "saude_emagrecimento": "🏃 Saúde / Fitness",
  "relacionamento": "💕 Relacionamento",
  "espiritualidade": "🔮 Espiritualidade",
  "geral": "📦 Geral"
};

const $ = (id) => document.getElementById(id);

function setStatus(text, kind) {
  $("status-text").textContent = text;
  const s = document.querySelector(".status");
  s.classList.remove("ok", "err");
  if (kind) s.classList.add(kind);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isLibraryUrl(url) {
  return url && /facebook\.com\/ads\/library/.test(url);
}

async function refreshStats() {
  const tab = await getActiveTab();
  if (!isLibraryUrl(tab?.url)) {
    setStatus("Abra a Biblioteca de Anúncios para escanear", "err");
    return;
  }
  setStatus("Conectado · escaneando", "ok");

  chrome.tabs.sendMessage(tab.id, { type: "GET_STATS" }, (resp) => {
    if (chrome.runtime.lastError || !resp || !resp.ok) {
      setStatus("Recarregue a página da Biblioteca", "err");
      return;
    }
    const s = resp.stats || {};
    $("s-low").textContent = s.low || 0;
    $("s-mid").textContent = s.mid || 0;
    $("s-high").textContent = s.high || 0;
    if ($("s-vid")) $("s-vid").textContent = s.withVideo || 0;
    if ($("s-lp"))  $("s-lp").textContent = s.withLp || 0;
    if ($("s-date")) $("s-date").textContent = s.withDate || 0;

    // contadores por tipo
    const t = s.types || {};
    if ($("t-ecom")) $("t-ecom").textContent = t.ecommerce || 0;
    if ($("t-digital")) $("t-digital").textContent = t.digital || 0;
    if ($("t-outro")) $("t-outro").textContent = t.outro || 0;
    if ($("t-serv")) $("t-serv").textContent = t.servico || 0;
    if ($("t-dor")) $("t-dor").textContent = t.dorama || 0;

    // sincroniza toggles com filtro do content
    const tf = s.typeFilter || {};
    if ($("tg-ecommerce")) $("tg-ecommerce").checked = tf.ecommerce !== false;
    if ($("tg-digital"))  $("tg-digital").checked  = tf.digital !== false;
    if ($("tg-outro"))    $("tg-outro").checked    = tf.outro !== false;
    if ($("tg-servico"))  $("tg-servico").checked  = !!tf.servico;
    if ($("tg-dorama"))   $("tg-dorama").checked   = !!tf.dorama;

    // sincroniza slider com filtro atual
    if ($("min-days") && s.minDaysFilter != null) {
      $("min-days").value = s.minDaysFilter;
      $("min-days-val").textContent = s.minDaysFilter;
    }

    const list = $("niche-list");
    list.innerHTML = "";
    const entries = Object.entries(s.niches || {}).sort((a, b) => b[1] - a[1]);
    if (entries.length === 0) {
      list.innerHTML = '<li class="empty">Sem dados ainda</li>';
    } else {
      for (const [n, c] of entries) {
        const li = document.createElement("li");
        li.innerHTML = `<span>${NICHE_LABEL[n] || n}</span><b>${c}</b>`;
        list.appendChild(li);
      }
    }
  });
}

async function setMinDays(value) {
  await chrome.storage.local.set({ minDaysFilter: value });
  const tab = await getActiveTab();
  if (isLibraryUrl(tab?.url)) {
    chrome.tabs.sendMessage(tab.id, { type: "SET_MIN_DAYS", value });
  }
}

const TYPE_KEYS = {
  "tg-ecommerce": "ecommerce",
  "tg-digital": "digital",
  "tg-outro": "outro",
  "tg-servico": "servico",
  "tg-dorama": "dorama"
};

async function setTypeFilter(key, value) {
  const cur = (await chrome.storage.local.get(["typeFilter"])).typeFilter || {};
  cur[key] = !!value;
  await chrome.storage.local.set({ typeFilter: cur });
  const tab = await getActiveTab();
  if (isLibraryUrl(tab?.url)) {
    chrome.tabs.sendMessage(tab.id, { type: "SET_TYPE_FILTER", filter: { [key]: !!value } });
  }
}

async function rescan() {
  const tab = await getActiveTab();
  if (!isLibraryUrl(tab?.url)) {
    setStatus("Abra a Biblioteca de Anúncios primeiro", "err");
    return;
  }
  chrome.tabs.sendMessage(tab.id, { type: "RESCAN" }, () => {
    setTimeout(refreshStats, 500);
  });
}

async function exportCsv() {
  const tab = await getActiveTab();
  if (!isLibraryUrl(tab?.url)) {
    setStatus("Abra a Biblioteca de Anúncios primeiro", "err");
    return;
  }
  chrome.tabs.sendMessage(tab.id, { type: "EXPORT_CSV" });
}

async function loadSaved() {
  const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
  $("saved-count").textContent = savedAds.length;
  const ul = $("saved-list");
  ul.innerHTML = "";
  if (savedAds.length === 0) {
    ul.innerHTML = '<li class="empty" style="text-align:center;color:#9ca3af;font-style:italic;padding:12px;">Nenhum anúncio salvo ainda</li>';
    return;
  }
  for (const ad of savedAds.slice().reverse()) {
    const li = document.createElement("li");
    const price = ad.priceRaw || (ad.price != null ? `R$ ${ad.price.toFixed(2)}` : "—");
    const daysHtml = ad.daysRunning != null
      ? `<span class="ad-days ${ad.daysRunning >= 30 ? 'fire' : ad.daysRunning >= 7 ? 'hot' : ''}">🔥 ${ad.daysRunning}d</span>`
      : "";
    const lpHtml = ad.landingPage
      ? `<a href="${escapeHtml(ad.landingPage)}" target="_blank" rel="noopener" class="ad-lp">🔗 LP</a>`
      : "";
    const vidHtml = ad.hasVideo ? `<span class="ad-vid">🎥</span>` : "";

    li.innerHTML = `
      <div class="ad-head">
        <span class="ad-adv">${escapeHtml(ad.advertiser || "Anunciante")}</span>
        <span class="ad-price">${escapeHtml(price)}</span>
      </div>
      <div class="ad-snip">${escapeHtml((ad.snippet || "").slice(0, 140))}…</div>
      <div class="ad-meta">
        <span>${NICHE_LABEL[ad.niche] || "📦"}</span>
        ${daysHtml}
        ${vidHtml}
        ${lpHtml}
        <span class="ad-date">${new Date(ad.capturedAt).toLocaleDateString("pt-BR")}</span>
      </div>
    `;
    ul.appendChild(li);
  }
}

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

async function exportSaved() {
  const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
  if (savedAds.length === 0) return;

  const rows = [[
    "anunciante","preco","ticket","nicho","gatilhos",
    "dias_rodando","data_inicio","tem_video","landing_page",
    "trecho","capturado_em"
  ]];
  for (const ad of savedAds) {
    rows.push([
      ad.advertiser || "",
      ad.price != null ? ad.price.toFixed(2) : "",
      ad.ticketClass || "",
      ad.niche || "",
      (ad.triggers || []).join("|"),
      ad.daysRunning != null ? ad.daysRunning : "",
      ad.startDate ? ad.startDate.slice(0, 10) : "",
      ad.hasVideo ? "sim" : "não",
      ad.landingPage || "",
      (ad.snippet || "").replace(/"/g, "'"),
      ad.capturedAt || ""
    ]);
  }
  const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  await chrome.downloads.download({
    url,
    filename: `low-ticket-favoritos_${new Date().toISOString().slice(0,10)}.csv`,
    saveAs: true
  }).catch(() => {
    // fallback se chrome.downloads não estiver disponível
    const a = document.createElement("a");
    a.href = url;
    a.download = `low-ticket-favoritos_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
  });
}

async function clearSaved() {
  if (!confirm("Limpar todos os favoritos?")) return;
  await chrome.storage.local.set({ savedAds: [] });
  loadSaved();
}

document.addEventListener("DOMContentLoaded", async () => {
  /* ---- verifica licença primeiro ---- */
  const license = await checkLicenseStatus();

  if (!license.valid) {
    showGate();

    // Botão ativar
    document.getElementById("btn-activate").addEventListener("click", async () => {
      const key = document.getElementById("license-input").value;
      const btn = document.getElementById("btn-activate");
      const msg = document.getElementById("gate-msg");

      btn.disabled = true;
      btn.textContent = "Verificando...";
      msg.className = "gate-msg hidden";

      try {
        const result = await activateLicense(key);
        msg.textContent = `✅ Ativado com sucesso! Bem-vindo(a)!`;
        msg.className = "gate-msg ok";
        msg.classList.remove("hidden");

        setTimeout(() => {
          showApp(result.email, result.expiresAt, false);
          refreshStats();
          loadSaved();
          initFilters();
        }, 1200);
      } catch (err) {
        msg.textContent = `❌ ${err.message}`;
        msg.className = "gate-msg err";
        msg.classList.remove("hidden");
        btn.disabled = false;
        btn.textContent = "Ativar agora";
      }
    });

    // Enter no input também ativa
    document.getElementById("license-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") document.getElementById("btn-activate").click();
    });

    return; // não inicializa o app ainda
  }

  /* ---- licença OK — inicia o app normalmente ---- */
  showApp(license.email, license.expiresAt, license.offline);
  refreshStats();
  loadSaved();
  initFilters();
});

async function initFilters() {

  // carrega filtro de dias salvo
  const { minDaysFilter = 0, typeFilter = {} } = await chrome.storage.local.get(["minDaysFilter", "typeFilter"]);
  if ($("min-days")) {
    $("min-days").value = minDaysFilter;
    $("min-days-val").textContent = minDaysFilter;
    $("min-days").addEventListener("input", (e) => {
      const v = parseInt(e.target.value, 10) || 0;
      $("min-days-val").textContent = v;
      setMinDays(v);
    });
  }

  // carrega + liga toggles de tipo
  const defaults = { ecommerce: true, digital: true, outro: true, servico: false, dorama: false };
  const tf = Object.assign({}, defaults, typeFilter);
  for (const [id, key] of Object.entries(TYPE_KEYS)) {
    const el = document.getElementById(id);
    if (!el) continue;
    el.checked = !!tf[key];
    el.addEventListener("change", (e) => setTypeFilter(key, e.target.checked));
  }

  $("btn-rescan").addEventListener("click", rescan);
  $("btn-export").addEventListener("click", exportCsv);
  $("btn-saved").addEventListener("click", () => {
    $("saved-section").classList.toggle("hidden");
  });
  $("btn-export-saved").addEventListener("click", exportSaved);
  $("btn-clear-saved").addEventListener("click", clearSaved);
  $("btn-open-library").addEventListener("click", () => {
    chrome.tabs.create({
      url: "https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=BR"
    });
  });
}
