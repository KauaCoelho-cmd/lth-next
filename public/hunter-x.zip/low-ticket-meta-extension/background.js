/* Hunter X v2.0 — service worker (MV3) */

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(["savedAds", "stats", "minDaysFilter"]);
  if (!cur.savedAds) await chrome.storage.local.set({ savedAds: [] });
  if (!cur.stats) await chrome.storage.local.set({ stats: { low: 0, mid: 0, high: 0, total: 0 } });
  if (cur.minDaysFilter == null) await chrome.storage.local.set({ minDaysFilter: 0 });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === "SAVE_AD") {
    (async () => {
      const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
      if (!savedAds.some(a => a.id === msg.data.id)) {
        savedAds.push(msg.data);
        await chrome.storage.local.set({ savedAds });
      }
      sendResponse({ ok: true, count: savedAds.length });
    })();
    return true;
  }

  if (msg.type === "STATS_UPDATE") {
    (async () => {
      await chrome.storage.local.set({ stats: msg.stats });
      if (sender.tab) {
        chrome.action.setBadgeText({
          tabId: sender.tab.id,
          text: msg.stats.low > 0 ? String(msg.stats.low) : ""
        });
        chrome.action.setBadgeBackgroundColor({ color: "#00c853" });
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.type === "GET_SAVED") {
    (async () => {
      const { savedAds = [] } = await chrome.storage.local.get(["savedAds"]);
      sendResponse({ ok: true, savedAds });
    })();
    return true;
  }

  if (msg.type === "FETCH_URL") {
    (async () => {
      try {
        const resp = await fetch(msg.url, {
          method: "GET",
          redirect: "follow",
          credentials: "omit",
          headers: { "User-Agent": "Mozilla/5.0" }
        });
        const ct = resp.headers.get("content-type") || "";
        const finalUrl = resp.url || msg.url;
        const buf = await resp.arrayBuffer();
        // Converte para base64 pra mandar via message (binary-safe)
        const bytes = new Uint8Array(buf);
        let bin = "";
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
          bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
        }
        const b64 = btoa(bin);
        sendResponse({
          ok: true,
          status: resp.status,
          contentType: ct,
          finalUrl,
          size: buf.byteLength,
          dataB64: b64
        });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true;
  }

  if (msg.type === "DOWNLOAD_VIDEO") {
    (async () => {
      try {
        const downloadId = await chrome.downloads.download({
          url: msg.url,
          filename: msg.filename || `meta-ad-${Date.now()}.mp4`,
          saveAs: false,
          conflictAction: "uniquify"
        });
        sendResponse({ ok: true, downloadId });
      } catch (err) {
        console.error("[LTH] download error:", err);
        sendResponse({ ok: false, error: String(err) });
      }
    })();
    return true;
  }
});
